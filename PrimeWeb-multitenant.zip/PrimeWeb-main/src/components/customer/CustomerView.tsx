import { useCurrency } from '../../utils/CurrencyContext';
import React, { useState } from 'react';
import { MenuItem, Category, DietaryTag, Order } from '../../types';
import { Search, Clock, Filter, Utensils, ShoppingBag, Plus, Check, SlidersHorizontal, ChefHat, Sparkles, QrCode, ArrowRight } from 'lucide-react';
import { Language, translations, getLocalizedMenuItem } from '../../lib/translations';

interface CustomerViewProps {
  menuItems: MenuItem[];
  tableNumber: number;
  tableComment?: string;
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  onSelectItem: (item: MenuItem) => void;
  onDirectAddToCart: (item: MenuItem) => void;
  cartCount: number;
  cartSubtotal: number;
  onOpenCart: () => void;
  onOpenQRScanner: () => void;
  onOpenLocation?: () => void;
  onOpenGoogleAuth?: () => void;
  activeOrder?: Order | null;
}

export const CustomerView: React.FC<CustomerViewProps> = ({
  menuItems,
  tableNumber,
  tableComment,
  onSelectItem,
  onDirectAddToCart,
  cartCount,
  cartSubtotal,
  onOpenCart,
  onOpenQRScanner,
  onOpenLocation,
  onOpenGoogleAuth,
  lang,
  onLanguageChange,
  activeOrder
}) => {
  const t = translations[lang];
  const { currency, setCurrency, formatPrice } = useCurrency();
  const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>('all');
  const [selectedDietary, setSelectedDietary] = useState<DietaryTag | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Track recently added item IDs for instant visual feedback
  const [recentlyAddedId, setRecentlyAddedId] = useState<string | null>(null);

  const categories: { id: Category | 'all'; label: string; icon: string }[] = [
    { id: 'all', label: t.catAll, icon: '🍽️' },
    { id: 'birinchi_taom', label: t.catBirinchiTaom, icon: '🍲' },
    { id: 'ikkinchi_taom', label: t.catIkkinchiTaom, icon: '🍛' },
    { id: 'garnir', label: t.catGarnir, icon: '🍟' },
    { id: 'salat', label: t.catSalat, icon: '🥗' },
    { id: 'nonushta', label: t.catNonushta, icon: '🍳' },
    { id: 'pizza', label: t.catPizza, icon: '🍕' },
    { id: 'ichimlik', label: t.catIchimlik, icon: '🍹' }
  ];

  const dietaryFilters: { id: DietaryTag | 'all'; label: string }[] = [
    { id: 'all', label: t.filterAll },
    { id: 'vegetarian', label: `${t.veg} 🥬` },
    { id: 'vegan', label: `${t.vegan} 🌱` },
    { id: 'gluten-free', label: `${t.glutenFree} 🌾` },
    { id: 'halal', label: `${t.halal} 🌙` },
    { id: 'spicy', label: `${t.spicy} 🔥` },
    { id: 'chef-recommendation', label: `${t.chefChoice} ⭐` }
  ];

  // Filtered menu logic
  const filteredItems = menuItems.filter(rawItem => {
    const item = getLocalizedMenuItem(rawItem, lang);
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesDietary = selectedDietary === 'all' || item.dietary.includes(selectedDietary as DietaryTag);
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          rawItem.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesDietary && matchesSearch;
  });

  // Featured Hero Item (first chef recommendation or special)
  const rawFeatured = menuItems.find(i => i.dietary.includes('chef-recommendation') && i.isAvailable && i.stock > 0) || menuItems[0];
  const featuredItem = rawFeatured ? getLocalizedMenuItem(rawFeatured, lang) : null;

  const handleQuickAdd = (e: React.MouseEvent, dish: MenuItem) => {
    e.stopPropagation();
    if (!dish.isAvailable || dish.stock <= 0) return;
    
    onDirectAddToCart(dish);
    setRecentlyAddedId(dish.id);
    setTimeout(() => {
      setRecentlyAddedId(null);
    }, 1200);
  };

  const getStatusStep = (status: string) => {
    switch (status) {
      case 'pending': return 1;
      case 'preparing': return 2;
      case 'ready': return 3;
      case 'served': return 4;
      default: return 1;
    }
  };

  const orderStep = activeOrder ? getStatusStep(activeOrder.status) : 0;

  return (
    <div className="pb-28 max-w-7xl mx-auto px-2.5 sm:px-6 lg:px-8 pt-3 sm:pt-6 space-y-4 sm:space-y-6">

      {/* Clean top header: table status, search, scan, currency, language —
          no filler cards, no cart tile (the header nav already has a cart
          button), so the actual menu appears as soon as possible. */}
      <div className="bg-white border border-zinc-200/90 rounded-2xl p-4 sm:p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center space-x-2">
            <span className="bg-orange-500 text-white font-black text-[10px] sm:text-xs px-2.5 py-0.5 rounded-lg uppercase tracking-wider shadow-xs">
              {t.table} #{tableNumber}
            </span>
            <span className="text-[10px] sm:text-xs text-green-700 font-bold bg-green-50 px-2 py-0.5 rounded-lg border border-green-200 flex items-center space-x-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
              <span>Kitchen Ready</span>
            </span>
          </div>

          {/* Language selector */}
          <div className="flex items-center gap-1">
            {(['uz', 'ru', 'en'] as const).map(code => (
              <button
                key={code}
                type="button"
                onClick={() => onLanguageChange(code)}
                className={`text-[10px] font-bold px-2 py-1 rounded-lg border transition-colors ${
                  lang === code
                    ? 'bg-zinc-900 text-white border-zinc-900'
                    : 'bg-white text-zinc-500 border-zinc-200 hover:border-zinc-300'
                }`}
              >
                {code === 'uz' ? "O'z" : code === 'ru' ? 'Рус' : 'Eng'}
              </button>
            ))}
          </div>
        </div>

        {tableComment && (
          <p className="text-[11px] text-orange-700 bg-orange-50 border border-orange-200 rounded-lg px-2 py-1 inline-flex items-center gap-1">
            📍 {tableComment}
          </p>
        )}

        {/* Search + Scan row */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={t.searchPlaceholder}
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-zinc-50 border border-zinc-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 shadow-xs transition-colors"
            />
          </div>
          <button
            onClick={onOpenQRScanner}
            className="bg-zinc-50 hover:bg-zinc-100 border border-zinc-200 text-orange-500 font-extrabold text-[11px] px-3 py-2.5 rounded-xl flex flex-col items-center justify-center shadow-xs transition-colors shrink-0"
            title={t.scanQR}
          >
            <QrCode className="w-4 h-4" />
            <span>{t.scanQR}</span>
          </button>
        </div>

        {/* Currency Display Toggle — so'm is always the real charged
            amount; USD/RUB are shown purely as a convenience conversion */}
        <div className="flex items-center justify-end gap-1">
          {(['UZS', 'USD', 'RUB'] as const).map(code => (
            <button
              key={code}
              type="button"
              onClick={() => setCurrency(code)}
              className={`text-[10px] font-bold px-2.5 py-1 rounded-lg border transition-colors ${
                currency === code
                  ? 'bg-orange-500 text-white border-orange-500'
                  : 'bg-white text-zinc-500 border-zinc-200 hover:border-zinc-300'
              }`}
            >
              {code === 'UZS' ? "so'm" : code === 'USD' ? '$ USD' : '₽ RUB'}
            </button>
          ))}
        </div>
      </div>

      {/* Active Order Tracker — only shown while an order is genuinely active */}
      {activeOrder && activeOrder.status !== 'paid' && (
        <div className="bg-gradient-to-br from-orange-500 to-amber-600 text-white border border-orange-400 rounded-2xl p-4 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-white/20 pb-2 mb-2">
              <div className="flex items-center space-x-1.5">
                <ChefHat className="w-4 h-4 text-amber-200" />
                <span className="text-xs font-black">Order #{activeOrder.id}</span>
              </div>
              <span className="text-[10px] bg-white/20 backdrop-blur-md px-2 py-0.5 rounded-md font-bold">
                Est. {activeOrder.estimatedMinutes}m
              </span>
            </div>

            <div className="text-xs font-bold text-amber-100 mb-1">
              {activeOrder.status === 'pending' && 'Order Received at Kitchen'}
              {activeOrder.status === 'preparing' && 'Chef is Cooking Your Dish'}
              {activeOrder.status === 'ready' && 'Ready to be Served!'}
              {activeOrder.status === 'served' && 'Served at Table'}
            </div>

            {/* Progress bar */}
            <div className="w-full bg-black/20 h-2 rounded-full overflow-hidden mt-2 border border-white/10">
              <div
                className="bg-white h-full transition-all duration-500"
                style={{ width: `${(orderStep / 4) * 100}%` }}
              />
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between text-[11px] font-semibold text-orange-100">
            <span>{activeOrder.items.length} items ordered</span>
            <span className="font-black text-white">{formatPrice(activeOrder.totalAmount)}</span>
          </div>
        </div>
      )}

      {/* 2. CATEGORY TABS & DIETARY CHIPS BENTO BAR */}
      <div className="bg-white border border-zinc-200/90 rounded-2xl p-3 shadow-xs space-y-2.5">
        
        {/* Category Tabs */}
        <div className="relative">
          <div className="flex items-center space-x-2 overflow-x-auto pb-1.5 pt-0.5 px-0.5 custom-scrollbar touch-pan-x overscroll-x-contain">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border shrink-0 ${
                  selectedCategory === cat.id
                    ? 'bg-orange-500 text-white border-orange-500 shadow-xs'
                    : 'bg-zinc-50 text-zinc-700 border-zinc-200 hover:bg-zinc-100 active:scale-95'
                }`}
              >
                <span className="text-sm shrink-0">{cat.icon}</span>
                <span className="shrink-0">{cat.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Dietary Tag Filter Chips */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pt-2 border-t border-zinc-100 custom-scrollbar touch-pan-x overscroll-x-contain">
          <span className="text-zinc-400 text-[11px] flex items-center space-x-1 shrink-0 font-semibold pl-1 pr-0.5">
            <Filter className="w-3 h-3 shrink-0" />
          </span>
          {dietaryFilters.map(d => (
            <button
              key={d.id}
              onClick={() => setSelectedDietary(d.id)}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-colors whitespace-nowrap border shrink-0 ${
                selectedDietary === d.id
                  ? 'bg-orange-50 text-orange-800 border-orange-200'
                  : 'bg-zinc-50 text-zinc-600 border-zinc-200 hover:text-zinc-900 active:scale-95'
              }`}
            >
              {d.label}
            </button>
          ))}
        </div>

      </div>

      {/* 3. FEATURED SPOTLIGHT BENTO HERO CARD (If available) */}
      {featuredItem && selectedCategory === 'all' && !searchQuery && (
        <div
          onClick={() => onSelectItem(featuredItem)}
          className="bg-white border border-zinc-200/90 rounded-2xl p-3.5 sm:p-5 shadow-xs hover:border-orange-400 transition-all cursor-pointer group relative overflow-hidden"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
            <div className="w-full h-40 sm:h-48 md:h-full bg-zinc-100 rounded-xl overflow-hidden relative">
              <img
                src={featuredItem.image}
                alt={featuredItem.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-2 left-2 bg-orange-500 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-md shadow-xs">
                ⭐ {t.chefChoice}
              </span>
            </div>

            <div className="md:col-span-2 space-y-2 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <h3 className="text-base sm:text-lg font-black text-zinc-900 group-hover:text-orange-600 transition-colors">
                    {featuredItem.name}
                  </h3>
                  <span className="text-base sm:text-xl font-black text-orange-600">
                    {formatPrice(featuredItem.price)}
                  </span>
                </div>
                <p className="text-xs text-zinc-500 mt-1 line-clamp-2 leading-relaxed font-medium">
                  {featuredItem.description}
                </p>
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-zinc-100">
                <div className="flex items-center space-x-1 text-xs text-zinc-400 font-semibold">
                  <Clock className="w-3.5 h-3.5 text-orange-500" />
                  <span>{t.prepTime.replace('{mins}', String(featuredItem.prepTimeMinutes))}</span>
                </div>

                <button
                  onClick={(e) => handleQuickAdd(e, featuredItem)}
                  className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-xl text-xs font-extrabold transition-all shadow-xs flex items-center space-x-1.5 active:scale-95"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>{t.addToOrder}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. DISHES BENTO GRID */}
      {filteredItems.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-zinc-200/90 my-4 shadow-xs">
          <Utensils className="w-10 h-10 text-zinc-400 mx-auto mb-2" />
          <p className="text-zinc-800 font-bold text-xs sm:text-sm">{t.noDishesFound}</p>
          <p className="text-[11px] text-zinc-500 mt-1">{t.tryResetFilters}</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-4 md:gap-5">
          {filteredItems.map((rawDish) => {
            const dish = getLocalizedMenuItem(rawDish, lang);
            const isRecentlyAdded = recentlyAddedId === dish.id;

            return (
              <div
                key={dish.id}
                onClick={() => dish.isAvailable && dish.stock > 0 && onSelectItem(rawDish)}
                className={`group bg-white border border-zinc-200/90 hover:border-orange-400 rounded-2xl p-2.5 sm:p-3.5 shadow-xs transition-all duration-200 flex flex-col justify-between ${
                  !dish.isAvailable || dish.stock === 0
                    ? 'opacity-60 cursor-not-allowed'
                    : 'cursor-pointer hover:shadow-md'
                }`}
              >
                <div>
                  {/* Food Image Container */}
                  <div className="w-full h-28 sm:h-36 bg-zinc-100 rounded-xl overflow-hidden relative mb-2">
                    <img
                      src={dish.image}
                      alt={dish.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>

                    {/* Stock Status Badge */}
                    <div className="absolute top-1.5 left-1.5 flex flex-col space-y-1">
                      {dish.stock <= 5 && dish.stock > 0 && (
                        <span className="bg-rose-500 text-white font-black text-[9px] px-1.5 py-0.5 rounded-md shadow-xs">
                          {t.onlyLeft.replace('{count}', String(dish.stock))}
                        </span>
                      )}
                      {(!dish.isAvailable || dish.stock === 0) && (
                        <span className="bg-zinc-900 text-white font-black text-[9px] px-1.5 py-0.5 rounded-md">
                          {t.soldOut}
                        </span>
                      )}
                    </div>

                    {/* Prep Time Badge */}
                    <div className="absolute top-1.5 right-1.5 flex items-center space-x-0.5 text-[9px] text-white bg-black/60 backdrop-blur-md px-1.5 py-0.5 rounded-md font-semibold">
                      <Clock className="w-2.5 h-2.5 text-orange-400" />
                      <span>{t.prepTime.replace('{mins}', String(dish.prepTimeMinutes))}</span>
                    </div>

                    {/* Price Tag */}
                    <div className="absolute bottom-1.5 left-2 text-white font-black text-sm sm:text-lg drop-shadow-md">
                      {formatPrice(dish.price)}
                    </div>

                    {/* Customizer Option Gear Trigger */}
                    {dish.isAvailable && dish.stock > 0 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectItem(rawDish);
                        }}
                        className="absolute bottom-1.5 right-1.5 bg-black/60 hover:bg-black/80 text-white p-1 rounded-lg backdrop-blur-md transition-colors"
                        title="Customize Options"
                      >
                        <SlidersHorizontal className="w-3 h-3" />
                      </button>
                    )}
                  </div>

                  {/* Card Content */}
                  <div>
                    <h4 className="font-extrabold text-xs sm:text-sm text-zinc-900 group-hover:text-orange-600 transition-colors line-clamp-1 leading-snug">
                      {dish.name}
                    </h4>
                    <p className="text-[10px] sm:text-xs text-zinc-500 mt-0.5 line-clamp-2 leading-tight">
                      {dish.description}
                    </p>
                  </div>
                </div>

                {/* Card Bottom Direct Add Action */}
                <div className="mt-2.5 pt-2 border-t border-zinc-100">
                  {dish.isAvailable && dish.stock > 0 ? (
                    <button
                      onClick={(e) => handleQuickAdd(e, rawDish)}
                      className={`w-full py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center space-x-1 shadow-xs active:scale-95 ${
                        isRecentlyAdded
                          ? 'bg-green-600 text-white'
                          : 'bg-orange-500 hover:bg-orange-600 text-white'
                      }`}
                    >
                      {isRecentlyAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>{t.added}</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5 stroke-[3]" />
                          <span>{t.addToOrder}</span>
                        </>
                      )}
                    </button>
                  ) : (
                    <button
                      disabled
                      className="w-full bg-zinc-100 text-zinc-400 py-2 rounded-xl text-xs font-bold cursor-not-allowed"
                    >
                      {t.soldOut}
                    </button>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Prime Restaurant Info & Contacts Footer Card */}
      <div className="bg-white border border-zinc-200/90 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-zinc-100 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-orange-500 rounded-2xl flex items-center justify-center text-white font-black text-lg shadow-sm">
              P
            </div>
            <div>
              <h3 className="font-black text-base text-zinc-900 uppercase tracking-tight">{t.appTitle}</h3>
              <p className="text-xs text-orange-600 font-bold flex items-center space-x-1">
                <span>📍 Samarkand, Uzbekistan</span>
              </p>
            </div>
          </div>

          {onOpenLocation && (
            <button
              onClick={onOpenLocation}
              className="bg-orange-50 hover:bg-orange-100 border border-orange-200 text-orange-800 font-extrabold text-xs px-3 py-2 rounded-xl transition-colors shadow-2xs"
            >
              View Location & Map →
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          {/* Instagram */}
          <a
            href="https://instagram.com/prime_cafe_bulvar"
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 bg-zinc-50 hover:bg-pink-50/80 border border-zinc-200/80 rounded-xl flex items-center space-x-2.5 text-xs font-extrabold text-zinc-800 transition-colors group"
          >
            <span className="p-2 bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white rounded-lg group-hover:scale-105 transition-transform">
              📸
            </span>
            <div className="overflow-hidden">
              <span className="text-[10px] text-zinc-400 font-bold block uppercase">Instagram</span>
              <span className="truncate text-zinc-900 font-black">@prime_cafe_bulvar</span>
            </div>
          </a>

          {/* Phone Call */}
          <a
            href={`tel:${t.phoneContact.replace(/\s/g, '')}`}
            className="p-3 bg-zinc-50 hover:bg-orange-50/80 border border-zinc-200/80 rounded-xl flex items-center space-x-2.5 text-xs font-extrabold text-zinc-800 transition-colors group"
          >
            <span className="p-2 bg-orange-500 text-white rounded-lg group-hover:scale-105 transition-transform">
              📞
            </span>
            <div className="overflow-hidden">
              <span className="text-[10px] text-zinc-400 font-bold block uppercase">Phone Number</span>
              <span className="truncate text-zinc-900 font-black">{t.phoneContact}</span>
            </div>
          </a>

          {/* WhatsApp Chat */}
          <a
            href={`https://wa.me/${t.whatsappContact.replace(/\D/g, '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 bg-zinc-50 hover:bg-emerald-50/80 border border-zinc-200/80 rounded-xl flex items-center space-x-2.5 text-xs font-extrabold text-zinc-800 transition-colors group"
          >
            <span className="p-2 bg-emerald-500 text-white rounded-lg group-hover:scale-105 transition-transform">
              💬
            </span>
            <div className="overflow-hidden">
              <span className="text-[10px] text-zinc-400 font-bold block uppercase">WhatsApp</span>
              <span className="truncate text-zinc-900 font-black">{t.whatsappContact}</span>
            </div>
          </a>
        </div>

        {/* Google Maps Feedback Banner */}
        <div className="pt-3 border-t border-zinc-100 flex flex-col sm:flex-row items-center justify-between gap-2.5 text-xs">
          <div className="flex items-center space-x-2">
            <span className="bg-amber-100 text-amber-800 font-black text-xs px-2 py-0.5 rounded-md flex items-center space-x-1">
              <span>4.9</span>
              <span>★</span>
            </span>
            <span className="text-zinc-600 font-bold">Google Maps Reviews:</span>
            <span className="text-zinc-900 font-extrabold italic">"Best food & atmosphere in Samarkand!"</span>
          </div>

          <a
            href="https://share.google/uBXjzlgV6n3vL9ha3"
            target="_blank"
            rel="noopener noreferrer"
            className="text-orange-600 hover:text-orange-700 font-black hover:underline flex items-center space-x-1 shrink-0"
          >
            <span>Read 280+ Reviews on Google Maps →</span>
          </a>
        </div>
      </div>

      {/* Floating Bottom Cart Review Bar for Mobile */}
      {cartCount > 0 && (
        <div className="fixed bottom-3 left-2.5 right-2.5 max-w-lg mx-auto z-40 animate-slideUp">
          <button
            onClick={onOpenCart}
            className="w-full bg-zinc-900 hover:bg-black text-white font-bold p-3 rounded-2xl shadow-2xl flex items-center justify-between transition-all transform active:scale-98 border border-zinc-800"
          >
            <div className="flex items-center space-x-2.5">
              <div className="bg-orange-500 text-white font-black text-xs sm:text-sm w-8 h-8 rounded-xl flex items-center justify-center shrink-0">
                {cartCount}
              </div>
              <div className="text-left">
                <div className="text-[10px] uppercase tracking-wider text-orange-400 font-black">{t.yourCart}</div>
                <div className="text-[11px] text-zinc-300 font-medium">{t.table} #{tableNumber} • {t.reviewOrder}</div>
              </div>
            </div>

            <div className="text-right flex items-center space-x-2">
              <span className="text-base sm:text-lg font-black text-orange-400">{formatPrice(cartSubtotal)}</span>
              <span className="bg-zinc-800 p-1.5 rounded-xl text-white text-xs">→</span>
            </div>
          </button>
        </div>
      )}

    </div>
  );
};
