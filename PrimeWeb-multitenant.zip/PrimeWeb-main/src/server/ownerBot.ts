import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import {
  createRestaurant,
  getRestaurantByPhone,
  getRestaurantById,
  getSubscription,
  listRestaurantsWithSubscriptions,
  setSubscriptionStatus
} from './db';

// ---------------------------------------------------------------------------
// This is Alex's PRIVATE bot for running PrimeWeb as a business — a second,
// completely separate bot from the customer-facing verification bot in
// telegram.ts. Only the Telegram account(s) listed in OWNER_TELEGRAM_IDS can
// issue commands to it. There is deliberately no payment gateway wired in:
// Alex collects payment however he likes (cash, click, payme, bank transfer)
// and then tells this bot to activate/extend/suspend a restaurant.
// ---------------------------------------------------------------------------

const OWNER_BOT_TOKEN = process.env.OWNER_BOT_TOKEN || '';
const OWNER_TELEGRAM_IDS = (process.env.OWNER_TELEGRAM_IDS || '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);

export const ownerBotConfigured = !!(OWNER_BOT_TOKEN && OWNER_TELEGRAM_IDS.length > 0);

async function sendOwnerMessage(chatId: number | string, text: string) {
  if (!OWNER_BOT_TOKEN) return;
  try {
    await fetch(`https://api.telegram.org/bot${OWNER_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML' })
    });
  } catch (err) {
    console.error('[ownerBot] failed to send message', err);
  }
}

export async function registerOwnerWebhook(publicUrl: string, secretToken: string) {
  if (!OWNER_BOT_TOKEN || !publicUrl) return;
  try {
    await fetch(`https://api.telegram.org/bot${OWNER_BOT_TOKEN}/setWebhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: `${publicUrl.replace(/\/$/, '')}/api/owner-bot/webhook`,
        secret_token: secretToken,
        allowed_updates: ['message']
      })
    });
  } catch (err) {
    console.error('[ownerBot] failed to register webhook', err);
  }
}

function generatePassword(): string {
  // 8 random alphanumeric chars — easy enough to read aloud/type over
  // Telegram, still resistant to guessing since login is also rate-limited
  // and lockout-protected server-side.
  return crypto.randomBytes(6).toString('base64').replace(/[^a-zA-Z0-9]/g, '').slice(0, 8) || 'pw' + Date.now();
}

function fmtRestaurant(r: {
  id: string;
  name: string;
  phone: string;
  sub_status?: string;
  sub_period_end?: string | null;
}): string {
  const status = r.sub_status || 'unknown';
  const emoji = status === 'active' ? '✅' : status === 'trial' ? '🕒' : status === 'suspended' ? '⛔️' : '❓';
  const period = r.sub_period_end ? new Date(r.sub_period_end).toLocaleDateString('uz-UZ') : 'muddatsiz';
  return `${emoji} <b>${r.name}</b>\n📞 ${r.phone}\n🆔 ${r.id}\n📅 holati: ${status} (tugash: ${period})`;
}

function findRestaurant(identifier: string) {
  const cleaned = identifier.trim();
  return getRestaurantByPhone(cleaned) || getRestaurantByPhone('+' + cleaned) || getRestaurantById(cleaned);
}

const HELP_TEXT = `<b>PrimeWeb boshqaruv boti</b>

/new &lt;telefon&gt; &lt;nomi&gt; — yangi restoran yaratish (parol avtomatik yaratiladi)
/list — barcha restoranlar ro'yxati va holati
/extend &lt;telefon yoki id&gt; &lt;kun&gt; — obunani shuncha kunga uzaytirish va faollashtirish
/activate &lt;telefon yoki id&gt; — obunani faollashtirish (muddatni o'zgartirmasdan)
/suspend &lt;telefon yoki id&gt; — obunani to'xtatish (restoran ishlamay qoladi)
/help — shu yordam matni`;

export async function handleOwnerBotMessage(message: any) {
  const from = message?.from;
  const text: string | undefined = message?.text;
  if (!from || !text) return;

  const fromId = String(from.id);
  if (!OWNER_TELEGRAM_IDS.includes(fromId)) {
    // Silently ignore anyone not on the whitelist — no hint given about
    // what this bot does or how to use it.
    return;
  }

  const parts = text.trim().split(/\s+/);
  const command = (parts[0] || '').toLowerCase();

  try {
    if (command === '/start' || command === '/help') {
      await sendOwnerMessage(from.id, HELP_TEXT);
      return;
    }

    if (command === '/new') {
      const phone = parts[1];
      const name = parts.slice(2).join(' ');
      if (!phone || !name) {
        await sendOwnerMessage(from.id, "Foydalanish: /new +998901234567 Old City Restaurant");
        return;
      }
      if (getRestaurantByPhone(phone)) {
        await sendOwnerMessage(from.id, `⚠️ Bu telefon raqam (${phone}) bilan restoran allaqachon mavjud.`);
        return;
      }
      const password = generatePassword();
      const passwordHash = bcrypt.hashSync(password, 12);
      const restaurant = createRestaurant({ name, phone, passwordHash });
      await sendOwnerMessage(
        from.id,
        `✅ Yangi restoran yaratildi!\n\n<b>${restaurant.name}</b>\n🆔 ${restaurant.id}\n\nMijozga bering:\n📞 Login: <code>${phone}</code>\n🔑 Parol: <code>${password}</code>\n\nSinov muddati: 14 kun. To'lov qilgach /extend buyrug'i bilan uzaytiring.`
      );
      return;
    }

    if (command === '/list') {
      const restaurants = listRestaurantsWithSubscriptions();
      if (restaurants.length === 0) {
        await sendOwnerMessage(from.id, 'Hozircha hech qanday restoran yo\'q.');
        return;
      }
      const chunks = restaurants.map(fmtRestaurant);
      // Telegram messages have a length limit — batch in groups of 10.
      for (let i = 0; i < chunks.length; i += 10) {
        await sendOwnerMessage(from.id, chunks.slice(i, i + 10).join('\n\n'));
      }
      return;
    }

    if (command === '/extend') {
      const identifier = parts[1];
      const days = Number(parts[2]);
      if (!identifier || !Number.isFinite(days) || days <= 0) {
        await sendOwnerMessage(from.id, 'Foydalanish: /extend +998901234567 30');
        return;
      }
      const restaurant = findRestaurant(identifier);
      if (!restaurant) {
        await sendOwnerMessage(from.id, `⚠️ Restoran topilmadi: ${identifier}`);
        return;
      }
      const existingSub = getSubscription(restaurant.id);
      const baseTime =
        existingSub?.current_period_end && new Date(existingSub.current_period_end).getTime() > Date.now()
          ? new Date(existingSub.current_period_end).getTime()
          : Date.now();
      const newPeriodEnd = new Date(baseTime + days * 24 * 60 * 60 * 1000).toISOString();
      setSubscriptionStatus(restaurant.id, 'active', newPeriodEnd, `Extended ${days} days by owner`);
      await sendOwnerMessage(
        from.id,
        `✅ <b>${restaurant.name}</b> obunasi ${days} kunga uzaytirildi.\nYangi tugash sanasi: ${new Date(
          newPeriodEnd
        ).toLocaleDateString('uz-UZ')}`
      );
      return;
    }

    if (command === '/activate') {
      const identifier = parts[1];
      const restaurant = identifier ? findRestaurant(identifier) : undefined;
      if (!restaurant) {
        await sendOwnerMessage(from.id, 'Foydalanish: /activate +998901234567');
        return;
      }
      setSubscriptionStatus(restaurant.id, 'active', null, 'Activated by owner (no expiry set)');
      await sendOwnerMessage(from.id, `✅ <b>${restaurant.name}</b> faollashtirildi (muddatsiz).`);
      return;
    }

    if (command === '/suspend') {
      const identifier = parts[1];
      const restaurant = identifier ? findRestaurant(identifier) : undefined;
      if (!restaurant) {
        await sendOwnerMessage(from.id, 'Foydalanish: /suspend +998901234567');
        return;
      }
      setSubscriptionStatus(restaurant.id, 'suspended', null, 'Suspended by owner');
      await sendOwnerMessage(from.id, `⛔️ <b>${restaurant.name}</b> to'xtatildi. Mijoz tizimga kira olmaydi.`);
      return;
    }

    await sendOwnerMessage(from.id, "Tushunmadim. /help yozing.");
  } catch (err) {
    console.error('[ownerBot] command failed', err);
    await sendOwnerMessage(from.id, "❌ Xatolik yuz berdi. Qaytadan urinib ko'ring.");
  }
}
