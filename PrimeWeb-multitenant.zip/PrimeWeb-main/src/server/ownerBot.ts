import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import {
  createRestaurant,
  getRestaurantByPhone,
  getRestaurantById,
  getSubscription,
  listRestaurantsWithSubscriptions,
  setSubscriptionStatus,
  setDeliveryStatus
} from './db';

// ---------------------------------------------------------------------------
// This is Alex's PRIVATE bot for running PrimeWeb as a business — a second,
// completely separate bot from the customer-facing verification bot in
// telegram.ts. Only the Telegram account(s) listed in OWNER_TELEGRAM_IDS can
// issue commands to it. There is deliberately no payment gateway wired in:
// Alex collects payment however he likes (cash, click, payme, bank transfer)
// and then tells this bot to activate/extend/suspend a restaurant.
// ---------------------------------------------------------------------------

const OWNER_BOT_TOKEN = process.env.OWNER_BOT_TOKEN || '';
const OWNER_TELEGRAM_IDS = (process.env.OWNER_TELEGRAM_IDS || '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);

export const ownerBotConfigured = !!(OWNER_BOT_TOKEN && OWNER_TELEGRAM_IDS.length > 0);

async function sendOwnerMessage(chatId: number | string, text: string) {
  if (!OWNER_BOT_TOKEN) return;
  try {
    await fetch(`https://api.telegram.org/bot${OWNER_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML' })
    });
  } catch (err) {
    console.error('[ownerBot] failed to send message', err);
  }
}

export async function registerOwnerWebhook(publicUrl: string, secretToken: string) {
  if (!OWNER_BOT_TOKEN || !publicUrl) return;
  try {
    await fetch(`https://api.telegram.org/bot${OWNER_BOT_TOKEN}/setWebhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: `${publicUrl.replace(/\/$/, '')}/api/owner-bot/webhook`,
        secret_token: secretToken,
        allowed_updates: ['message']
      })
    });
  } catch (err) {
    console.error('[ownerBot] failed to register webhook', err);
  }
}

function generatePassword(): string {
  // 8 random alphanumeric chars — easy enough to read aloud/type over
  // Telegram, still resistant to guessing since login is also rate-limited
  // and lockout-protected server-side.
  return crypto.randomBytes(6).toString('base64').replace(/[^a-zA-Z0-9]/g, '').slice(0, 8) || 'pw' + Date.now();
}

function fmtRestaurant(r: {
  id: string;
  name: string;
  phone: string;
  sub_status?: string;
  sub_period_end?: string | null;
}): string {
  const status = r.sub_status || 'unknown';
  const emoji = status === 'active' ? '✅' : status === 'trial' ? '🕒' : status === 'suspended' ? '⛔️' : '❓';
  const period = r.sub_period_end ? new Date(r.sub_period_end).toLocaleDateString('uz-UZ') : 'muddatsiz';
  return `${emoji} <b>${r.name}</b>\n📞 ${r.phone}\n🆔 ${r.id}\n📅 holati: ${status} (tugash: ${period})`;
}

function findRestaurant(identifier: string) {
  const cleaned = identifier.trim();
  return getRestaurantByPhone(cleaned) || getRestaurantByPhone('+' + cleaned) || getRestaurantById(cleaned);
}

const HELP_TEXT = `<b>PrimeWeb boshqaruv boti</b>

/new &lt;telefon&gt; &lt;nomi&gt; — yangi restoran yaratish (parol avtomatik yaratiladi)
/list — barcha restoranlar ro'yxati va holati
/extend &lt;telefon yoki id&gt; &lt;kun&gt; — obunani shuncha kunga uzaytirish va faollashtirish
/activate &lt;telefon yoki id&gt; — obunani faollashtirish (muddatni o'zgartirmasdan)
/suspend &lt;telefon yoki id&gt; — obunani to'xtatish (restoran ishlamay qoladi)
/expiring — muddati yaqin yoki o'tgan restoranlar ro'yxati
/delivery_on &lt;telefon&gt; — dostavka xizmatini yoqish
/delivery_off &lt;telefon&gt; — dostavka xizmatini o'chirish
/help — shu yordam matni`;

export async function handleOwnerBotMessage(message: any) {
  const from = message?.from;
  const text: string | undefined = message?.text;
  if (!from || !text) return;

  const fromId = String(from.id);
  if (!OWNER_TELEGRAM_IDS.includes(fromId)) {
    // Silently ignore anyone not on the whitelist — no hint given about
    // what this bot does or how to use it.
    return;
  }

  const parts = text.trim().split(/\s+/);
  const command = (parts[0] || '').toLowerCase();

  try {
    if (command === '/start' || command === '/help') {
      await sendOwnerMessage(from.id, HELP_TEXT);
      return;
    }

    if (command === '/new') {
      const phone = parts[1];
      const name = parts.slice(2).join(' ');
      if (!phone || !name) {
        await sendOwnerMessage(from.id, "Foydalanish: /new +998901234567 Old City Restaurant");
        return;
      }
      if (getRestaurantByPhone(phone)) {
        await sendOwnerMessage(from.id, `⚠️ Bu telefon raqam (${phone}) bilan restoran allaqachon mavjud.`);
        return;
      }
      const password = generatePassword();
      const passwordHash = bcrypt.hashSync(password, 12);
      const restaurant = createRestaurant({ name, phone, passwordHash });
      await sendOwnerMessage(
        from.id,
        `✅ Yangi restoran yaratildi!\n\n<b>${restaurant.name}</b>\n🆔 ${restaurant.id}\n\nMijozga bering:\n📞 Login: <code>${phone}</code>\n🔑 Parol: <code>${password}</code>\n\nSinov muddati: 14 kun. To'lov qilgach /extend buyrug'i bilan uzaytiring.`
      );
      return;
    }

    if (command === '/list') {
      const restaurants = listRestaurantsWithSubscriptions();
      if (restaurants.length === 0) {
        await sendOwnerMessage(from.id, 'Hozircha hech qanday restoran yo\'q.');
        return;
      }
      const chunks = restaurants.map(fmtRestaurant);
      // Telegram messages have a length limit — batch in groups of 10.
      for (let i = 0; i < chunks.length; i += 10) {
        await sendOwnerMessage(from.id, chunks.slice(i, i + 10).join('\n\n'));
      }
      return;
    }

    if (command === '/extend') {
      const identifier = parts[1];
      const days = Number(parts[2]);
      if (!identifier || !Number.isFinite(days) || days <= 0) {
        await sendOwnerMessage(from.id, 'Foydalanish: /extend +998901234567 30');
        return;
      }
      const restaurant = findRestaurant(identifier);
      if (!restaurant) {
        await sendOwnerMessage(from.id, `⚠️ Restoran topilmadi: ${identifier}`);
        return;
      }
      const existingSub = getSubscription(restaurant.id);
      const baseTime =
        existingSub?.current_period_end && new Date(existingSub.current_period_end).getTime() > Date.now()
          ? new Date(existingSub.current_period_end).getTime()
          : Date.now();
      const newPeriodEnd = new Date(baseTime + days * 24 * 60 * 60 * 1000).toISOString();
      setSubscriptionStatus(restaurant.id, 'active', newPeriodEnd, `Extended ${days} days by owner`);
      await sendOwnerMessage(
        from.id,
        `✅ <b>${restaurant.name}</b> obunasi ${days} kunga uzaytirildi.\nYangi tugash sanasi: ${new Date(
          newPeriodEnd
        ).toLocaleDateString('uz-UZ')}`
      );
      return;
    }

    if (command === '/activate') {
      const identifier = parts[1];
      const restaurant = identifier ? findRestaurant(identifier) : undefined;
      if (!restaurant) {
        await sendOwnerMessage(from.id, 'Foydalanish: /activate +998901234567');
        return;
      }
      setSubscriptionStatus(restaurant.id, 'active', null, 'Activated by owner (no expiry set)');
      await sendOwnerMessage(from.id, `✅ <b>${restaurant.name}</b> faollashtirildi (muddatsiz).`);
      return;
    }

    if (command === '/suspend') {
      const identifier = parts[1];
      const restaurant = identifier ? findRestaurant(identifier) : undefined;
      if (!restaurant) {
        await sendOwnerMessage(from.id, 'Foydalanish: /suspend +998901234567');
        return;
      }
      setSubscriptionStatus(restaurant.id, 'suspended', null, 'Suspended by owner');
      await sendOwnerMessage(from.id, `⛔️ <b>${restaurant.name}</b> to'xtatildi. Mijoz tizimga kira olmaydi.`);
      return;
    }

    if (command === '/delivery_on') {
      const identifier = parts[1];
      const restaurant = identifier ? findRestaurant(identifier) : undefined;
      if (!restaurant) {
        await sendOwnerMessage(from.id, 'Foydalanish: /delivery_on +998901234567');
        return;
      }
      setDeliveryStatus(restaurant.id, 'active');
      await sendOwnerMessage(
        from.id,
        `✅ <b>${restaurant.name}</b> uchun dostavka xizmati yoqildi. Admin endi kuryer ulashi mumkin.`
      );
      return;
    }

    if (command === '/delivery_off') {
      const identifier = parts[1];
      const restaurant = identifier ? findRestaurant(identifier) : undefined;
      if (!restaurant) {
        await sendOwnerMessage(from.id, 'Foydalanish: /delivery_off +998901234567');
        return;
      }
      setDeliveryStatus(restaurant.id, 'disabled');
      await sendOwnerMessage(from.id, `⛔️ <b>${restaurant.name}</b> uchun dostavka xizmati o'chirildi.`);
      return;
    }

    if (command === '/expiring') {
      await checkExpiringSubscriptionsAndNotifyOwnerForOne(from.id);
      return;
    }

    await sendOwnerMessage(from.id, "Tushunmadim. /help yozing.");
  } catch (err) {
    console.error('[ownerBot] command failed', err);
    await sendOwnerMessage(from.id, "❌ Xatolik yuz berdi. Qaytadan urinib ko'ring.");
  }
}

// ---------------------------------------------------------------------------
// Daily reminder: messages every whitelisted owner about any restaurant
// whose subscription expires within OWNER_EXPIRY_REMINDER_DAYS (default 3)
// days, and about any restaurant that expired since the last check and is
// now effectively cut off. Meant to be called once a day from server.ts —
// this is the whole "don't forget to collect payment" safety net, with no
// payment gateway involved.
// ---------------------------------------------------------------------------
const EXPIRY_REMINDER_DAYS = Number(process.env.OWNER_EXPIRY_REMINDER_DAYS) || 3;

function buildExpiryReportLines(): string[] {
  const now = Date.now();
  const reminderWindowMs = EXPIRY_REMINDER_DAYS * 24 * 60 * 60 * 1000;
  const restaurants = listRestaurantsWithSubscriptions();

  const expiringSoon = restaurants.filter(r => {
    if (r.sub_status === 'suspended' || !r.sub_period_end) return false;
    const end = new Date(r.sub_period_end).getTime();
    return end > now && end - now <= reminderWindowMs;
  });

  const justExpired = restaurants.filter(r => {
    if (r.sub_status === 'suspended' || !r.sub_period_end) return false;
    const end = new Date(r.sub_period_end).getTime();
    // Only flag ones that expired within the last 24h, so the automatic
    // daily check doesn't repeat forever for a restaurant Alex already
    // knows about and is simply choosing not to suspend yet.
    return end <= now && now - end <= 24 * 60 * 60 * 1000;
  });

  const lines: string[] = [];
  if (expiringSoon.length > 0) {
    lines.push('⏰ <b>Tez orada tugaydigan obunalar:</b>');
    for (const r of expiringSoon) {
      const daysLeft = Math.ceil((new Date(r.sub_period_end as string).getTime() - now) / (24 * 60 * 60 * 1000));
      lines.push(`• ${r.name} (${r.phone}) — ${daysLeft} kun qoldi`);
    }
  }
  if (justExpired.length > 0) {
    if (lines.length > 0) lines.push('');
    lines.push("⚠️ <b>Muddati o'tgan (hali to'xtatilmagan):</b>");
    for (const r of justExpired) {
      lines.push(`• ${r.name} (${r.phone})`);
    }
    lines.push('');
    lines.push("To'lov kelganda: /extend +raqam kun_soni");
  }
  return lines;
}

// Called once a day from server.ts — silently does nothing if there's
// nothing to report, so it never spams the owner with empty messages.
export async function checkExpiringSubscriptionsAndNotifyOwner() {
  if (!ownerBotConfigured) return;
  try {
    const lines = buildExpiryReportLines();
    if (lines.length === 0) return;
    for (const ownerId of OWNER_TELEGRAM_IDS) {
      await sendOwnerMessage(ownerId, lines.join('\n'));
    }
  } catch (err) {
    console.error('[ownerBot] expiry reminder check failed', err);
  }
}

// Called from the /expiring command — always replies, even if nothing is
// expiring soon, since a person explicitly asked.
async function checkExpiringSubscriptionsAndNotifyOwnerForOne(chatId: number | string) {
  try {
    const lines = buildExpiryReportLines();
    await sendOwnerMessage(chatId, lines.length > 0 ? lines.join('\n') : "✅ Hozircha muddati yaqin restoran yo'q.");
  } catch (err) {
    console.error('[ownerBot] /expiring command failed', err);
  }
}
