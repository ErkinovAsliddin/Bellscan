import { z } from 'zod';

// Every field a client can send is validated and bounded here. This is what
// stops malformed/malicious payloads (huge strings, wrong types, negative
// prices, XSS payloads in text fields, etc.) from ever reaching the database.

const safeText = (max: number) => z.string().trim().min(1).max(max);

export const customizationOptionSchema = z.object({
  id: z.string().max(64),
  name: safeText(120),
  price: z.number().finite().min(0).max(100000)
});

export const customizationGroupSchema = z.object({
  id: z.string().max(64),
  title: safeText(120),
  required: z.boolean(),
  maxSelect: z.number().int().min(1).max(20).optional(),
  options: z.array(customizationOptionSchema).max(30)
});

const imageField = z
  .string()
  .max(4_000_000) // generous enough for a base64-encoded uploaded photo
  .refine(val => val === '' || val.startsWith('data:image/') || /^https?:\/\//.test(val), {
    message: 'image must be a valid http(s) URL, an uploaded image, or empty'
  })
  .optional();

export const menuItemCreateSchema = z.object({
  nameUz: safeText(120),
  nameRu: safeText(120),
  nameEn: safeText(120),
  descriptionUz: z.string().trim().max(2000).optional().default(''),
  descriptionRu: z.string().trim().max(2000).optional().default(''),
  descriptionEn: z.string().trim().max(2000).optional().default(''),
  price: z.number().finite().min(0).max(1_000_000),
  category: z.enum(['birinchi_taom', 'ikkinchi_taom', 'garnir', 'salat', 'nonushta', 'pizza', 'ichimlik']),
  image: imageField,
  stock: z.number().int().min(0).max(100000).optional().default(20),
  dietary: z.array(z.enum(['vegetarian', 'vegan', 'gluten-free', 'halal', 'spicy', 'chef-recommendation'])).max(10).optional().default([]),
  prepTimeMinutes: z.number().int().min(0).max(600).optional().default(12),
  customizations: z.array(customizationGroupSchema).max(20).optional().default([])
});

export const menuItemUpdateSchema = menuItemCreateSchema.partial().extend({
  isAvailable: z.boolean().optional(),
  stockReason: z.enum(['restock', 'manual_adjustment', 'spoilage', 'customer_order']).optional()
});

const selectedCustomizationSchema = z.object({
  groupTitle: safeText(120),
  optionName: safeText(120),
  price: z.number().finite().min(0).max(100000)
});

const cartItemSchema = z.object({
  cartItemId: z.string().max(100),
  menuItem: z.object({ id: z.string().max(64) }).passthrough(),
  quantity: z.number().int().min(1).max(50),
  selectedCustomizations: z.array(selectedCustomizationSchema).max(30).default([]),
  specialInstructions: z.string().trim().max(500).optional(),
  itemTotal: z.number().finite().min(0).max(1_000_000)
});

export const orderCreateSchema = z.object({
  tableNumber: z.number().int().min(0).max(9999), // 0 is used as the "no physical table" sentinel for delivery orders
  customerName: z.string().trim().max(120).optional(),
  customerPhoneOrEmail: z.string().trim().max(200).optional(),
  items: z.array(cartItemSchema).min(1).max(100),
  subtotal: z.number().finite().min(0).max(10_000_000),
  tax: z.number().finite().min(0).max(10_000_000),
  serviceCharge: z.number().finite().min(0).max(10_000_000),
  discount: z.number().finite().min(0).max(10_000_000).optional().default(0),
  totalAmount: z.number().finite().min(0).max(10_000_000),
  loyaltyPointsRedeemed: z.number().int().min(0).max(10_000_000).optional().default(0),
  paymentMethod: z.enum(['cash', 'card', 'loyalty_points', 'pay_at_counter']).optional().default('pay_at_counter'),
  orderNote: z.string().trim().max(500).optional(),
  orderType: z.enum(['dine_in', 'delivery']).optional().default('dine_in'),
  deliveryAddress: z.string().trim().max(300).optional(),
  deliveryPhone: z
    .string()
    .trim()
    .regex(/^\+?[0-9]{7,15}$/, "Telefon raqam noto'g'ri formatda")
    .optional()
});

export const orderStatusUpdateSchema = z.object({
  status: z.enum(['pending', 'preparing', 'ready', 'out_for_delivery', 'served', 'paid', 'cancelled']).optional(),
  paymentStatus: z.enum(['unpaid', 'paid']).optional()
}).refine(d => d.status || d.paymentStatus, { message: 'status or paymentStatus is required' });

export const tableCreateSchema = z.object({
  tableNumber: z.number().int().min(1).max(9999),
  capacity: z.number().int().min(1).max(50).optional().default(4),
  comment: z.string().trim().max(300).optional().default('')
});

export const loyaltyRegisterSchema = z.object({
  name: safeText(120),
  phoneOrEmail: z.string().trim().min(3).max(200),
  confirmationCode: z.string().trim().max(20).optional()
});

export const loginSchema = z.object({
  password: z.string().min(1).max(200)
});

const phoneField = z
  .string()
  .trim()
  .min(7)
  .max(20)
  .regex(/^\+?[0-9]{7,15}$/, "Telefon raqam noto'g'ri formatda (masalan: +998901234567)");

// Restaurant staff (admin/kitchen) now log in with their restaurant's phone
// number + password, since the phone number is what identifies WHICH
// restaurant they belong to in a multi-tenant system.
export const phoneLoginSchema = z.object({
  phone: phoneField,
  password: z.string().min(1).max(200)
});

export const restaurantRegisterSchema = z.object({
  name: safeText(150),
  phone: phoneField,
  password: z.string().min(6).max(200),
  deliveryEnabled: z.boolean().optional().default(false)
});

export const ownerCreateRestaurantSchema = z.object({
  name: safeText(150),
  phone: phoneField
});

export const ownerSubscriptionUpdateSchema = z.object({
  restaurantId: z.string().min(1).max(100),
  status: z.enum(['trial', 'active', 'suspended']),
  extendDays: z.number().int().min(0).max(3650).optional()
});

export const googleVerifySchema = z.object({
  credential: z.string().min(20).max(4000)
});

export const exchangeRateUpdateSchema = z.object({
  currency: z.enum(['USD', 'RUB']),
  rateToSom: z.number().finite().min(0.01).max(1_000_000)
});

export const settingsUpdateSchema = z.object({
  taxPercent: z.number().finite().min(0).max(50).optional(),
  serviceFeePercent: z.number().finite().min(0).max(50).optional()
}).refine(d => d.taxPercent !== undefined || d.serviceFeePercent !== undefined, {
  message: 'At least one of taxPercent or serviceFeePercent is required'
});

export const changePasswordSchema = z.object({
  newPassword: z.string().min(4).max(200)
});

export const brandingUpdateSchema = z.object({
  logoUrl: imageField,
  brandColor: z
    .string()
    .trim()
    .regex(/^#[0-9a-fA-F]{6}$/, 'brandColor must be a hex color like #f97316')
    .optional()
});

export const waiterCallSchema = z.object({
  tableNumber: z.number().int().min(1).max(9999)
});

export const printerSettingsSchema = z.object({
  printerIp: z
    .string()
    .trim()
    .regex(/^(\d{1,3}\.){3}\d{1,3}$/, 'printerIp must be a valid IPv4 address')
    .optional()
    .or(z.literal('')),
  printerPort: z.number().int().min(1).max(65535).optional()
});

export const deliveryOrderFieldsSchema = z.object({
  orderType: z.enum(['dine_in', 'delivery']).optional(),
  deliveryAddress: safeText(300).optional(),
  deliveryPhone: z
    .string()
    .trim()
    .regex(/^\+?[0-9]{7,15}$/, "Telefon raqam noto'g'ri formatda")
    .optional()
});

export const courierNameUpdateSchema = z.object({
  name: safeText(80)
});
