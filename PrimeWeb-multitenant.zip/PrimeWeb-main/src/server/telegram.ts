import { db } from './db';
import crypto from 'crypto';

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const BOT_USERNAME = process.env.TELEGRAM_BOT_USERNAME || '';
const TOKEN_TTL_MINUTES = 5;

export const telegramConfigured = !!(BOT_TOKEN && BOT_USERNAME);

export function createVerificationToken(
  opts: { purpose?: 'customer' | 'admin_notify' | 'courier_link'; restaurantId?: string } = {}
): { token: string; deepLink: string } {
  const token = crypto.randomBytes(16).toString('hex');
  const now = new Date();
  const expiresAt = new Date(now.getTime() + TOKEN_TTL_MINUTES * 60_000);
  db.prepare(
    `INSERT INTO telegram_verifications (token, status, created_at, expires_at, purpose, restaurant_id) VALUES (?, 'pending', ?, ?, ?, ?)`
  ).run(token, now.toISOString(), expiresAt.toISOString(), opts.purpose || 'customer', opts.restaurantId || null);
  return { token, deepLink: `https://t.me/${BOT_USERNAME}?start=${token}` };
}

export function getVerificationStatus(token: string) {
  const row = db
    .prepare(
      `SELECT status, telegram_user_id, telegram_username, telegram_first_name, expires_at, purpose, restaurant_id FROM telegram_verifications WHERE token = ?`
    )
    .get(token) as
    | {
        status: string;
        telegram_user_id: string | null;
        telegram_username: string | null;
        telegram_first_name: string | null;
        expires_at: string;
        purpose: string;
        restaurant_id: string | null;
      }
    | undefined;

  if (!row) return { status: 'not_found' as const };
  if (row.status === 'pending' && new Date(row.expires_at).getTime() < Date.now()) {
    return { status: 'expired' as const };
  }
  return {
    status: row.status as 'pending' | 'verified',
    telegramUserId: row.telegram_user_id || undefined,
    telegramUsername: row.telegram_username || undefined,
    telegramFirstName: row.telegram_first_name || undefined,
    purpose: (row.purpose || 'customer') as 'customer' | 'admin_notify' | 'courier_link',
    restaurantId: row.restaurant_id || undefined
  };
}

export function markVerified(
  token: string,
  user: { id: number; username?: string; first_name?: string }
): { ok: boolean; purpose?: 'customer' | 'admin_notify' | 'courier_link'; restaurantId?: string } {
  const row = db
    .prepare(`SELECT status, expires_at, purpose, restaurant_id FROM telegram_verifications WHERE token = ?`)
    .get(token) as { status: string; expires_at: string; purpose: string; restaurant_id: string | null } | undefined;
  if (!row || row.status !== 'pending') return { ok: false };
  if (new Date(row.expires_at).getTime() < Date.now()) return { ok: false };

  db.prepare(
    `UPDATE telegram_verifications SET status = 'verified', telegram_user_id = ?, telegram_username = ?, telegram_first_name = ? WHERE token = ?`
  ).run(String(user.id), user.username || '', user.first_name || '', token);
  return {
    ok: true,
    purpose: (row.purpose || 'customer') as 'customer' | 'admin_notify' | 'courier_link',
    restaurantId: row.restaurant_id || undefined
  };
}

// Minimal Telegram Bot API client — just enough to send a confirmation
// message back to the customer after they tap "Start" in the bot.
export async function sendTelegramMessage(chatId: number | string, text: string) {
  if (!BOT_TOKEN) return;
  try {
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text })
    });
  } catch {
    // Best-effort — if this fails the customer still sees success in the
    // browser via polling, they just don't get the bot's confirmation text.
  }
}

export async function registerWebhook(publicUrl: string, secretToken: string) {
  if (!BOT_TOKEN || !publicUrl) return;
  try {
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: `${publicUrl.replace(/\/$/, '')}/api/telegram/webhook`,
        secret_token: secretToken,
        allowed_updates: ['message']
      })
    });
  } catch (err) {
    console.error('Failed to register Telegram webhook', err);
  }
}
