import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { INITIAL_MENU_ITEMS, INITIAL_ORDERS, INITIAL_TABLES, INITIAL_LOYALTY_MEMBERS } from '../data/mockData';

// --------------------------------------------------------------------------
// Persistent database (SQLite file on disk). Multi-tenant: every restaurant
// that signs up gets its own row in `restaurants`, and every business table
// (menu_items, orders, tables, loyalty_members, inventory_logs, settings,
// exchange_rates, staff_accounts) is scoped by restaurant_id so one
// restaurant can never see or touch another's data.
// --------------------------------------------------------------------------

const DATA_DIR = process.env.DATABASE_DIR || path.join(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const DB_PATH = process.env.DATABASE_PATH || path.join(DATA_DIR, 'restaurant.db');

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL'); // safer/faster concurrent writes, and crash-resistant
db.pragma('foreign_keys = ON');

const LEGACY_RESTAURANT_ID = 'default';

export function genId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${crypto.randomBytes(4).toString('hex')}`;
}

function tableExists(name: string): boolean {
  const row = db.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name=?`).get(name);
  return !!row;
}

function columnExists(table: string, column: string): boolean {
  const rows = db.prepare(`PRAGMA table_info(${table})`).all() as { name: string }[];
  return rows.some(r => r.name === column);
}

// ---------------------------------------------------------------------------
// Base schema: every business table is created multi-tenant from the start
// (restaurant_id baked into the primary key). If this is a brand new
// database file, these CREATE TABLE IF NOT EXISTS calls are all that run.
// ---------------------------------------------------------------------------
function createBaseSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS restaurants (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    -- One row per restaurant, tracking whether its monthly subscription is
    -- paid. Deliberately has NO payment gateway plumbing: Alex (the owner
    -- of PrimeWeb itself) manages this by hand via the owner Telegram bot
    -- after collecting payment offline.
    CREATE TABLE IF NOT EXISTS subscriptions (
      restaurant_id TEXT PRIMARY KEY REFERENCES restaurants(id) ON DELETE CASCADE,
      status TEXT NOT NULL DEFAULT 'trial', -- 'trial' | 'active' | 'suspended'
      current_period_end TEXT, -- ISO date; NULL means no expiry tracked yet
      note TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS menu_items (
      restaurant_id TEXT NOT NULL,
      id TEXT NOT NULL,
      data TEXT NOT NULL,
      PRIMARY KEY (restaurant_id, id)
    );

    CREATE TABLE IF NOT EXISTS orders (
      restaurant_id TEXT NOT NULL,
      id TEXT NOT NULL,
      table_number INTEGER NOT NULL,
      data TEXT NOT NULL,
      created_at TEXT NOT NULL,
      PRIMARY KEY (restaurant_id, id)
    );
    CREATE INDEX IF NOT EXISTS idx_orders_restaurant_created ON orders (restaurant_id, created_at);

    CREATE TABLE IF NOT EXISTS tables (
      restaurant_id TEXT NOT NULL,
      table_number INTEGER NOT NULL,
      data TEXT NOT NULL,
      PRIMARY KEY (restaurant_id, table_number)
    );

    CREATE TABLE IF NOT EXISTS loyalty_members (
      restaurant_id TEXT NOT NULL,
      id TEXT NOT NULL,
      phone_or_email TEXT NOT NULL,
      data TEXT NOT NULL,
      PRIMARY KEY (restaurant_id, id)
    );
    CREATE INDEX IF NOT EXISTS idx_loyalty_restaurant_contact ON loyalty_members (restaurant_id, phone_or_email);

    CREATE TABLE IF NOT EXISTS inventory_logs (
      restaurant_id TEXT NOT NULL,
      id TEXT NOT NULL,
      data TEXT NOT NULL,
      created_at TEXT NOT NULL,
      PRIMARY KEY (restaurant_id, id)
    );

    -- Admin/kitchen accounts, one pair per restaurant. Passwords are always
    -- stored as bcrypt hashes, never plaintext.
    CREATE TABLE IF NOT EXISTS staff_accounts (
      restaurant_id TEXT NOT NULL,
      role TEXT NOT NULL, -- 'admin' | 'kitchen'
      password_hash TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY (restaurant_id, role)
    );

    CREATE TABLE IF NOT EXISTS idempotency_keys (
      key TEXT PRIMARY KEY,
      order_id TEXT NOT NULL,
      restaurant_id TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS settings (
      restaurant_id TEXT NOT NULL,
      key TEXT NOT NULL,
      value TEXT NOT NULL,
      PRIMARY KEY (restaurant_id, key)
    );

    CREATE TABLE IF NOT EXISTS exchange_rates (
      restaurant_id TEXT NOT NULL,
      currency TEXT NOT NULL,
      rate_to_som REAL NOT NULL,
      updated_at TEXT NOT NULL,
      source TEXT NOT NULL DEFAULT 'manual',
      PRIMARY KEY (restaurant_id, currency)
    );

    -- Telegram bot verification for CUSTOMERS proving they control a
    -- Telegram account. Not restaurant-specific data worth isolating.
    CREATE TABLE IF NOT EXISTS telegram_verifications (
      token TEXT PRIMARY KEY,
      status TEXT NOT NULL DEFAULT 'pending',
      telegram_user_id TEXT,
      telegram_username TEXT,
      telegram_first_name TEXT,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS login_attempts (
      restaurant_id TEXT NOT NULL,
      role TEXT NOT NULL,
      failed_count INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      PRIMARY KEY (restaurant_id, role)
    );
  `);
}

// ---------------------------------------------------------------------------
// Upgrade path for a database file created by the OLD single-restaurant
// version of this app (no restaurant_id anywhere). Detected by: the
// `restaurants` table not existing yet, but `staff_accounts` already having
// data in the old shape (role TEXT PRIMARY KEY, no restaurant_id column).
// Everything that already exists gets tagged as restaurant_id='default' so
// an already-running restaurant (e.g. the live restaurant.publicvm.com
// deployment) keeps working exactly as before after this upgrade, just now
// as tenant #1 of a multi-tenant system.
// ---------------------------------------------------------------------------
function migrateLegacySingleTenantData() {
  const hadOldStaffAccounts =
    tableExists('staff_accounts') && !columnExists('staff_accounts', 'restaurant_id');
  if (!hadOldStaffAccounts) return; // fresh DB, or already migrated

  console.log('[db] Detected pre-multi-tenant database — migrating existing data into a "default" restaurant tenant...');

  const now = new Date().toISOString();

  let legacyAdminHash: string | null = null;
  try {
    const row = db.prepare(`SELECT password_hash FROM staff_accounts WHERE role = 'admin'`).get() as
      | { password_hash: string }
      | undefined;
    legacyAdminHash = row?.password_hash || null;
  } catch {
    /* old table may not exist at all — that's fine */
  }

  const placeholderHash = legacyAdminHash || bcrypt.hashSync(crypto.randomBytes(16).toString('hex'), 12);

  db.prepare(
    `INSERT INTO restaurants (id, name, phone, password_hash, created_at, updated_at)
     SELECT ?, 'Restoran', ?, ?, ?, ?
     WHERE NOT EXISTS (SELECT 1 FROM restaurants WHERE id = ?)`
  ).run(LEGACY_RESTAURANT_ID, `${LEGACY_RESTAURANT_ID}-legacy`, placeholderHash, now, now, LEGACY_RESTAURANT_ID);

  db.prepare(
    `INSERT INTO subscriptions (restaurant_id, status, current_period_end, note, created_at, updated_at)
     SELECT ?, 'active', NULL, 'Migrated from single-tenant version — always active, manage manually.', ?, ?
     WHERE NOT EXISTS (SELECT 1 FROM subscriptions WHERE restaurant_id = ?)`
  ).run(LEGACY_RESTAURANT_ID, now, now, LEGACY_RESTAURANT_ID);

  // Copy staff_accounts (old shape: role PK) into the new composite-key shape.
  const oldStaff = db.prepare(`SELECT role, password_hash, updated_at FROM staff_accounts`).all() as {
    role: string;
    password_hash: string;
    updated_at: string;
  }[];
  db.exec(`ALTER TABLE staff_accounts RENAME TO staff_accounts_old_legacy;`);
  db.exec(`
    CREATE TABLE staff_accounts (
      restaurant_id TEXT NOT NULL,
      role TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY (restaurant_id, role)
    );
  `);
  const insertStaff = db.prepare(
    'INSERT INTO staff_accounts (restaurant_id, role, password_hash, updated_at) VALUES (?, ?, ?, ?)'
  );
  for (const row of oldStaff) {
    insertStaff.run(LEGACY_RESTAURANT_ID, row.role, row.password_hash, row.updated_at);
  }
  db.exec(`DROP TABLE staff_accounts_old_legacy;`);

  // Copy login_attempts (old shape: role PK).
  if (tableExists('login_attempts') && !columnExists('login_attempts', 'restaurant_id')) {
    const oldAttempts = db.prepare(`SELECT role, failed_count, locked_until FROM login_attempts`).all() as {
      role: string;
      failed_count: number;
      locked_until: string | null;
    }[];
    db.exec(`ALTER TABLE login_attempts RENAME TO login_attempts_old_legacy;`);
    db.exec(`
      CREATE TABLE login_attempts (
        restaurant_id TEXT NOT NULL,
        role TEXT NOT NULL,
        failed_count INTEGER NOT NULL DEFAULT 0,
        locked_until TEXT,
        PRIMARY KEY (restaurant_id, role)
      );
    `);
    const insertAttempt = db.prepare(
      'INSERT INTO login_attempts (restaurant_id, role, failed_count, locked_until) VALUES (?, ?, ?, ?)'
    );
    for (const row of oldAttempts) {
      insertAttempt.run(LEGACY_RESTAURANT_ID, row.role, row.failed_count, row.locked_until);
    }
    db.exec(`DROP TABLE login_attempts_old_legacy;`);
  }

  type Migration = { table: string; oldCols: string; newCreate: string; copyCols: string };
  const migrations: Migration[] = [
    {
      table: 'menu_items',
      oldCols: 'id, data',
      newCreate: `CREATE TABLE menu_items (restaurant_id TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL, PRIMARY KEY (restaurant_id, id));`,
      copyCols: 'restaurant_id, id, data'
    },
    {
      table: 'orders',
      oldCols: 'id, table_number, data, created_at',
      newCreate: `CREATE TABLE orders (restaurant_id TEXT NOT NULL, id TEXT NOT NULL, table_number INTEGER NOT NULL, data TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY (restaurant_id, id));`,
      copyCols: 'restaurant_id, id, table_number, data, created_at'
    },
    {
      table: 'tables',
      oldCols: 'table_number, data',
      newCreate: `CREATE TABLE tables (restaurant_id TEXT NOT NULL, table_number INTEGER NOT NULL, data TEXT NOT NULL, PRIMARY KEY (restaurant_id, table_number));`,
      copyCols: 'restaurant_id, table_number, data'
    },
    {
      table: 'loyalty_members',
      oldCols: 'id, phone_or_email, data',
      newCreate: `CREATE TABLE loyalty_members (restaurant_id TEXT NOT NULL, id TEXT NOT NULL, phone_or_email TEXT NOT NULL, data TEXT NOT NULL, PRIMARY KEY (restaurant_id, id));`,
      copyCols: 'restaurant_id, id, phone_or_email, data'
    },
    {
      table: 'inventory_logs',
      oldCols: 'id, data, created_at',
      newCreate: `CREATE TABLE inventory_logs (restaurant_id TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY (restaurant_id, id));`,
      copyCols: 'restaurant_id, id, data, created_at'
    },
    {
      table: 'settings',
      oldCols: 'key, value',
      newCreate: `CREATE TABLE settings (restaurant_id TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY (restaurant_id, key));`,
      copyCols: 'restaurant_id, key, value'
    },
    {
      table: 'exchange_rates',
      oldCols: 'currency, rate_to_som, updated_at, source',
      newCreate: `CREATE TABLE exchange_rates (restaurant_id TEXT NOT NULL, currency TEXT NOT NULL, rate_to_som REAL NOT NULL, updated_at TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'manual', PRIMARY KEY (restaurant_id, currency));`,
      copyCols: 'restaurant_id, currency, rate_to_som, updated_at, source'
    }
  ];

  for (const m of migrations) {
    if (!tableExists(m.table) || columnExists(m.table, 'restaurant_id')) continue; // already new shape
    const oldRows = db.prepare(`SELECT ${m.oldCols} FROM ${m.table}`).all() as Record<string, unknown>[];
    db.exec(`ALTER TABLE ${m.table} RENAME TO ${m.table}_old_legacy;`);
    db.exec(m.newCreate);
    const placeholders = m.copyCols.split(', ').map(() => '?').join(', ');
    const insert = db.prepare(`INSERT INTO ${m.table} (${m.copyCols}) VALUES (${placeholders})`);
    const oldColNames = m.oldCols.split(', ');
    for (const row of oldRows) {
      insert.run(LEGACY_RESTAURANT_ID, ...oldColNames.map(c => row[c]));
    }
    db.exec(`DROP TABLE ${m.table}_old_legacy;`);
  }

  if (tableExists('idempotency_keys') && !columnExists('idempotency_keys', 'restaurant_id')) {
    db.exec(`ALTER TABLE idempotency_keys ADD COLUMN restaurant_id TEXT NOT NULL DEFAULT '${LEGACY_RESTAURANT_ID}';`);
  }

  console.log('[db] Migration complete. Existing restaurant is now tenant id "default".');
}

createBaseSchema();
migrateLegacySingleTenantData();

// ---------------------------------------------------------------------------
// Restaurant / subscription helpers
// ---------------------------------------------------------------------------
export interface RestaurantRow {
  id: string;
  name: string;
  phone: string;
  password_hash: string;
  created_at: string;
  updated_at: string;
}

export interface SubscriptionRow {
  restaurant_id: string;
  status: 'trial' | 'active' | 'suspended';
  current_period_end: string | null;
  note: string | null;
}

export function getRestaurantByPhone(phone: string): RestaurantRow | undefined {
  return db.prepare('SELECT * FROM restaurants WHERE phone = ?').get(phone) as RestaurantRow | undefined;
}

export function getRestaurantById(id: string): RestaurantRow | undefined {
  return db.prepare('SELECT * FROM restaurants WHERE id = ?').get(id) as RestaurantRow | undefined;
}

export function getSubscription(restaurantId: string): SubscriptionRow | undefined {
  return db.prepare('SELECT * FROM subscriptions WHERE restaurant_id = ?').get(restaurantId) as
    | SubscriptionRow
    | undefined;
}

export function isSubscriptionUsable(restaurantId: string): boolean {
  const sub = getSubscription(restaurantId);
  if (!sub) return false;
  if (sub.status === 'suspended') return false;
  if (sub.current_period_end && new Date(sub.current_period_end).getTime() < Date.now()) return false;
  return sub.status === 'trial' || sub.status === 'active';
}

const DEFAULT_TRIAL_DAYS = Number(process.env.DEFAULT_TRIAL_DAYS) || 14;

export function createRestaurant(params: { name: string; phone: string; passwordHash: string }): RestaurantRow {
  const id = genId('rest');
  const now = new Date().toISOString();
  const trialEnd = new Date(Date.now() + DEFAULT_TRIAL_DAYS * 24 * 60 * 60 * 1000).toISOString();

  const tx = db.transaction(() => {
    db.prepare(
      'INSERT INTO restaurants (id, name, phone, password_hash, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(id, params.name, params.phone, params.passwordHash, now, now);

    db.prepare(
      'INSERT INTO subscriptions (restaurant_id, status, current_period_end, note, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(id, 'trial', trialEnd, `${DEFAULT_TRIAL_DAYS}-day trial from signup`, now, now);

    // The restaurants.password_hash column is kept for reference, but the
    // actual credential CHECKED at login time lives in staff_accounts
    // (restaurant_id, role) — so the admin role must be seeded here too,
    // otherwise a freshly registered restaurant can never log in.
    db.prepare(
      "INSERT INTO staff_accounts (restaurant_id, role, password_hash, updated_at) VALUES (?, 'admin', ?, ?)"
    ).run(id, params.passwordHash, now);

    db.prepare(`INSERT INTO settings (restaurant_id, key, value) VALUES (?, 'taxPercent', '8')`).run(id);
    db.prepare(`INSERT INTO settings (restaurant_id, key, value) VALUES (?, 'serviceFeePercent', '5')`).run(id);
    db.prepare(
      `INSERT INTO exchange_rates (restaurant_id, currency, rate_to_som, updated_at, source) VALUES (?, 'USD', 12000, ?, 'manual')`
    ).run(id, now);
    db.prepare(
      `INSERT INTO exchange_rates (restaurant_id, currency, rate_to_som, updated_at, source) VALUES (?, 'RUB', 150, ?, 'manual')`
    ).run(id, now);
  });
  tx();

  return getRestaurantById(id) as RestaurantRow;
}

export function listRestaurantsWithSubscriptions(): (RestaurantRow & Partial<SubscriptionRow>)[] {
  return db
    .prepare(
      `SELECT r.*, s.status as sub_status, s.current_period_end as sub_period_end, s.note as sub_note
       FROM restaurants r LEFT JOIN subscriptions s ON s.restaurant_id = r.id
       ORDER BY r.created_at DESC`
    )
    .all() as any;
}

export function setSubscriptionStatus(
  restaurantId: string,
  status: 'trial' | 'active' | 'suspended',
  periodEndIso: string | null,
  note?: string
) {
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO subscriptions (restaurant_id, status, current_period_end, note, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(restaurant_id) DO UPDATE SET status = ?, current_period_end = ?, note = COALESCE(?, subscriptions.note), updated_at = ?`
  ).run(restaurantId, status, periodEndIso, note || null, now, now, status, periodEndIso, note || null, now);
}

// ---------------------------------------------------------------------------
// Legacy demo seed data — only used in local dev so the app isn't empty out
// of the box. Real restaurants that sign up via /api/restaurants/register
// start with an empty menu/tables, which is correct — they add their own.
// ---------------------------------------------------------------------------
function seedLegacyDemoDataIfNeeded() {
  if (process.env.NODE_ENV === 'production') return; // never auto-seed demo data in prod
  if (getRestaurantById(LEGACY_RESTAURANT_ID)) return; // already migrated/created

  const now = new Date().toISOString();
  const demoPassword = process.env.ADMIN_INITIAL_PASSWORD;
  if (!demoPassword) return; // nothing to bootstrap with locally

  db.prepare(
    'INSERT INTO restaurants (id, name, phone, password_hash, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(LEGACY_RESTAURANT_ID, 'Demo Restoran', '+998900000000', bcrypt.hashSync(demoPassword, 12), now, now);
  db.prepare(
    'INSERT INTO subscriptions (restaurant_id, status, current_period_end, note, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(LEGACY_RESTAURANT_ID, 'active', null, 'Local dev demo tenant', now, now);

  const insertMenu = db.prepare('INSERT INTO menu_items (restaurant_id, id, data) VALUES (?, ?, ?)');
  for (const item of INITIAL_MENU_ITEMS) insertMenu.run(LEGACY_RESTAURANT_ID, item.id, JSON.stringify(item));

  const insertOrder = db.prepare(
    'INSERT INTO orders (restaurant_id, id, table_number, data, created_at) VALUES (?, ?, ?, ?, ?)'
  );
  for (const o of INITIAL_ORDERS)
    insertOrder.run(LEGACY_RESTAURANT_ID, o.id, o.tableNumber, JSON.stringify(o), o.createdAt);

  const insertTable = db.prepare('INSERT INTO tables (restaurant_id, table_number, data) VALUES (?, ?, ?)');
  for (const t of INITIAL_TABLES) insertTable.run(LEGACY_RESTAURANT_ID, t.tableNumber, JSON.stringify(t));

  const insertLoyalty = db.prepare(
    'INSERT INTO loyalty_members (restaurant_id, id, phone_or_email, data) VALUES (?, ?, ?, ?)'
  );
  for (const l of INITIAL_LOYALTY_MEMBERS)
    insertLoyalty.run(LEGACY_RESTAURANT_ID, l.id, l.phoneOrEmail.toLowerCase(), JSON.stringify(l));

  const kitchenPin = process.env.KITCHEN_INITIAL_PIN || demoPassword;
  db.prepare(
    "INSERT INTO staff_accounts (restaurant_id, role, password_hash, updated_at) VALUES (?, 'admin', ?, ?)"
  ).run(LEGACY_RESTAURANT_ID, bcrypt.hashSync(demoPassword, 12), now);
  db.prepare(
    "INSERT INTO staff_accounts (restaurant_id, role, password_hash, updated_at) VALUES (?, 'kitchen', ?, ?)"
  ).run(LEGACY_RESTAURANT_ID, bcrypt.hashSync(kitchenPin, 12), now);
}

seedLegacyDemoDataIfNeeded();

export function backupNow(): string {
  const backupDir = path.join(DATA_DIR, 'backups');
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupPath = path.join(backupDir, `restaurant-${stamp}.db`);
  db.backup(backupPath).then(() => {
    // no-op; backup is async under the hood in better-sqlite3's API surface
  });
  return backupPath;
}
