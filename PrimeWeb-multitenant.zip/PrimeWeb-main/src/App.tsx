import React, { useState, useEffect } from 'react';
import {
  AppViewMode,
  MenuItem,
  Order,
  Table,
  LoyaltyMember,
  CartItem,
  OrderStatus,
  GoogleUser,
  WaiterCall
} from './types';
import { INITIAL_MENU_ITEMS, INITIAL_ORDERS, INITIAL_TABLES, INITIAL_LOYALTY_MEMBERS } from './data/mockData';
import { Language } from './lib/translations';
import { playOrderChimeSound } from './utils/audio';
import { HeaderNav } from './components/HeaderNav';
import { TableConfirmModal } from './components/customer/TableConfirmModal';
import { CustomerView } from './components/customer/CustomerView';
import { ItemCustomizerModal } from './components/customer/ItemCustomizerModal';
import { CartDrawer } from './components/customer/CartDrawer';
import { OrderStatusTracker } from './components/customer/OrderStatusTracker';
import { OrderHistoryModal } from './components/customer/OrderHistoryModal';
import { QRScannerModal } from './components/customer/QRScannerModal';
import { GoogleAuthModal } from './components/customer/GoogleAuthModal';
import { RestaurantLocationModal } from './components/customer/RestaurantLocationModal';
import { WelcomeSplash } from './components/customer/WelcomeSplash';
import { KitchenDisplay } from './components/kitchen/KitchenDisplay';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { OnboardingWizard } from './components/admin/OnboardingWizard';
import { AdminAuthModal } from './components/admin/AdminAuthModal';
import { CurrencyProvider } from './utils/CurrencyContext';
import { withRestaurantParam, setRestaurantId } from './utils/restaurantContext';

export default function App() {
  // Multilingual State
  const [lang, setLang] = useState<Language>('uz'); // Default to Uzbek as requested

  // App View State
  const [currentView, setCurrentView] = useState<AppViewMode>('customer');
  const [isRealtimeConnected, setIsRealtimeConnected] = useState<boolean>(true);

  // Admin & Kitchen Security Authentication State.
  // The actual credential check happens server-side (hashed password, real
  // session cookie) — these booleans just mirror what the server told us via
  // /api/auth/me so the UI can show/hide the right screens.
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);
  const [isKitchenAuthenticated, setIsKitchenAuthenticated] = useState<boolean>(false);
  const [loggedInRestaurantId, setLoggedInRestaurantId] = useState<string>('default');
  const [loggedInRestaurantName, setLoggedInRestaurantName] = useState<string | null>(null);
  const [subscriptionPeriodEnd, setSubscriptionPeriodEnd] = useState<string | null>(null);
  const [subscriptionBlocked, setSubscriptionBlocked] = useState<boolean>(false);
  const [deliveryStatus, setDeliveryStatus] = useState<'disabled' | 'active' | 'suspended'>('disabled');
  const [orderMode, setOrderMode] = useState<'dine_in' | 'delivery'>('dine_in');
  const [deliveryAddress, setDeliveryAddress] = useState<string>('');
  const [deliveryPhone, setDeliveryPhone] = useState<string>('');
  const [onboardingDismissed, setOnboardingDismissed] = useState<boolean>(false);
  const [isAdminAuthModalOpen, setIsAdminAuthModalOpen] = useState<boolean>(false);
  const [authModalTarget, setAuthModalTarget] = useState<'kitchen' | 'admin'>('admin');

  // Simple visible error queue so failed actions are never silently
  // swallowed or faked as successes.
  const [errorToast, setErrorToast] = useState<string | null>(null);
  const showError = (message: string) => {
    setErrorToast(message);
    window.setTimeout(() => setErrorToast(null), 5000);
  };

  // Turns the server's zod validation error shape into a readable message,
  // e.g. "price: Number must be greater than 0" instead of a generic
  // "invalid request" that gives no clue what to fix.
  const describeApiError = (body: any): string | null => {
    if (!body) return null;
    if (body.details?.fieldErrors) {
      const fields = Object.entries(body.details.fieldErrors)
        .filter(([, msgs]) => Array.isArray(msgs) && (msgs as string[]).length > 0)
        .map(([field, msgs]) => `${field}: ${(msgs as string[])[0]}`);
      if (fields.length > 0) return `Invalid: ${fields.join('; ')}`;
    }
    return body.error || null;
  };

  const handleUpdateAdminPassword = async (newPass: string) => {
    try {
      const res = await fetch('/api/auth/admin/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword: newPass })
      });
      if (!res.ok) throw new Error('Failed to update password');
    } catch {
      showError('Could not update admin password. Please try again.');
    }
  };

  const handleUpdateKitchenPin = async (newPin: string) => {
    try {
      const res = await fetch('/api/auth/kitchen/change-pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword: newPin })
      });
      if (!res.ok) throw new Error('Failed to update PIN');
    } catch {
      showError('Could not update kitchen PIN. Please try again.');
    }
  };

  // Restore session state on load/refresh (server is the source of truth).
  useEffect(() => {
    fetch('/api/auth/me')
      .then(r => (r.ok ? r.json() : { role: null }))
      .then(({ role, restaurantId, restaurantName, subscriptionPeriodEnd, subscriptionActive, deliveryStatus }) => {
        setIsAdminAuthenticated(role === 'admin');
        setIsKitchenAuthenticated(role === 'admin' || role === 'kitchen');
        if (restaurantId) {
          setLoggedInRestaurantId(restaurantId);
          setRestaurantId(restaurantId);
        }
        if (restaurantName) setLoggedInRestaurantName(restaurantName);
        if (subscriptionPeriodEnd) setSubscriptionPeriodEnd(subscriptionPeriodEnd);
        if (deliveryStatus) setDeliveryStatus(deliveryStatus);
        if ((role === 'admin' || role === 'kitchen') && subscriptionActive === false) {
          setSubscriptionBlocked(true);
        }
      })
      .catch(() => {});
  }, []);

  // QR Camera Scanner State
  const [isQRScannerModalOpen, setIsQRScannerModalOpen] = useState<boolean>(false);

  // Data Stores
  const [menuItems, setMenuItems] = useState<MenuItem[]>(INITIAL_MENU_ITEMS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [tables, setTables] = useState<Table[]>(INITIAL_TABLES);
  const [loyaltyMembers, setLoyaltyMembers] = useState<LoyaltyMember[]>(INITIAL_LOYALTY_MEMBERS);
  const [waiterCalls, setWaiterCalls] = useState<WaiterCall[]>([]);
  const [branding, setBranding] = useState<{
    logoUrl: string | null;
    brandColor: string | null;
    restaurantName: string | null;
    contactPhone: string | null;
    contactAddress: string | null;
    contactInstagram: string | null;
    workingHours: string | null;
  }>({
    logoUrl: null,
    brandColor: null,
    restaurantName: null,
    contactPhone: null,
    contactAddress: null,
    contactInstagram: null,
    workingHours: null
  });

  // Table State
  const [tableNumber, setTableNumber] = useState<number | null>(null);
  const [isTableModalOpen, setIsTableModalOpen] = useState<boolean>(false);

  // Cart & Customizer State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [selectedDishForCustomization, setSelectedDishForCustomization] = useState<MenuItem | null>(null);

  // Loyalty & Customer Identification State
  const [googleUser, setGoogleUser] = useState<GoogleUser | null>(() => {
    const saved = localStorage.getItem('prime_restaurant_google_user');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { return null; }
    }
    return null;
  });
  const [isGoogleAuthModalOpen, setIsGoogleAuthModalOpen] = useState<boolean>(false);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<boolean>(false);
  const [isWelcomeSplashOpen, setIsWelcomeSplashOpen] = useState<boolean>(true);

  const [customerName, setCustomerName] = useState<string>(() => googleUser?.name || '');
  const [customerPhoneOrEmail, setCustomerPhoneOrEmail] = useState<string>(() => googleUser?.email || '');
  const [confirmationCode, setConfirmationCode] = useState<string>('');
  const [currentLoyaltyMember, setCurrentLoyaltyMember] = useState<LoyaltyMember | null>(null);
  const [isLoyaltyModalOpen, setIsLoyaltyModalOpen] = useState<boolean>(false);

  const handleSignInGoogle = (user: GoogleUser) => {
    setGoogleUser(user);
    setCustomerName(user.name);
    setCustomerPhoneOrEmail(user.email);
    localStorage.setItem('prime_restaurant_google_user', JSON.stringify(user));
  };

  const handleSignOutGoogle = () => {
    setGoogleUser(null);
    localStorage.removeItem('prime_restaurant_google_user');
  };

  // Active Customer Order Tracker
  const [activeCustomerOrder, setActiveCustomerOrder] = useState<Order | null>(null);

  // App Base URL for QR generation
  const appUrl = window.location.origin;

  // Real-time updates: two scoped SSE streams below (customer table-scoped,
  // and staff full-detail), instead of one broadcast-everything stream.
  // Customer real-time stream: scoped to this table only (order status +
  // menu/table availability). Reopens whenever the table number changes.
  useEffect(() => {
    if (orderMode === 'delivery') {
      // Nothing to subscribe to until the customer has actually placed a
      // delivery order — and scoped to that ONE order, never a shared
      // channel, so one delivery customer's address/phone/items can never
      // reach another customer of the same restaurant.
      if (!activeCustomerOrder?.id) return;
      const eventSource = new EventSource(withRestaurantParam(`/api/events/order/${activeCustomerOrder.id}`));
      eventSource.onopen = () => setIsRealtimeConnected(true);
      eventSource.onerror = () => setIsRealtimeConnected(false);
      eventSource.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if ((payload.type === 'ORDER_CREATED' || payload.type === 'ORDER_UPDATED') && payload.data.order) {
            setOrders(prev => {
              const exists = prev.some(o => o.id === payload.data.order.id);
              return exists
                ? prev.map(o => (o.id === payload.data.order.id ? payload.data.order : o))
                : [payload.data.order, ...prev];
            });
          }
        } catch (e) {
          console.error('Error parsing SSE event', e);
        }
      };
      return () => eventSource.close();
    }

    if (!tableNumber) return;
    const eventSource = new EventSource(withRestaurantParam(`/api/events/table/${tableNumber}`));
    eventSource.onopen = () => setIsRealtimeConnected(true);
    eventSource.onerror = () => setIsRealtimeConnected(false);
    eventSource.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'ORDER_CREATED' || payload.type === 'ORDER_UPDATED') {
          if (payload.data.order) {
            setOrders(prev => {
              const exists = prev.some(o => o.id === payload.data.order.id);
              return exists
                ? prev.map(o => (o.id === payload.data.order.id ? payload.data.order : o))
                : [payload.data.order, ...prev];
            });
          }
        } else if (payload.type === 'MENU_UPDATED') {
          if (Array.isArray(payload.data)) setMenuItems(payload.data);
        } else if (payload.type === 'TABLE_INFO_UPDATED') {
          if (payload.data?.tableNumber !== undefined) {
            setTables(prev =>
              prev.map(t => (t.tableNumber === payload.data.tableNumber ? { ...t, comment: payload.data.comment } : t))
            );
          }
        }
      } catch (e) {
        console.error('Error parsing SSE event', e);
      }
    };
    return () => eventSource.close();
  }, [tableNumber, orderMode, activeCustomerOrder?.id]);

  // Staff real-time stream: full order/menu/table detail. Only opens once
  // logged into the admin or kitchen view (session-gated on the server too).
  useEffect(() => {
    if (!isAdminAuthenticated && !isKitchenAuthenticated) return;
    const eventSource = new EventSource('/api/events');
    eventSource.onopen = () => setIsRealtimeConnected(true);
    eventSource.onerror = () => setIsRealtimeConnected(false);
    eventSource.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'ORDER_CREATED') {
          if (payload.data.order) {
            setOrders(prev => [payload.data.order, ...prev.filter(o => o.id !== payload.data.order.id)]);
          }
        } else if (payload.type === 'ORDER_UPDATED') {
          if (payload.data.order) {
            setOrders(prev => prev.map(o => (o.id === payload.data.order.id ? payload.data.order : o)));
          }
        } else if (payload.type === 'MENU_UPDATED') {
          if (Array.isArray(payload.data)) setMenuItems(payload.data);
        } else if (payload.type === 'TABLES_UPDATED') {
          if (Array.isArray(payload.data)) setTables(payload.data);
        } else if (payload.type === 'ORDER_DELETED') {
          if (payload.data?.id) setOrders(prev => prev.filter(o => o.id !== payload.data.id));
        } else if (payload.type === 'ORDERS_CLEANED_UP') {
          fetchStaffState(); // simplest correct way to reflect a bulk deletion
        } else if (payload.type === 'WAITER_CALL') {
          setWaiterCalls(prev => [payload.data, ...prev]);
          playOrderChimeSound();
        } else if (payload.type === 'WAITER_CALL_RESOLVED') {
          if (payload.data?.id) {
            setWaiterCalls(prev => prev.map(c => (c.id === payload.data.id ? { ...c, status: 'resolved' } : c)));
          }
        }
      } catch (e) {
        console.error('Error parsing SSE event', e);
      }
    };
    return () => eventSource.close();
  }, [isAdminAuthenticated, isKitchenAuthenticated]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlView = params.get('view');
    const urlTable = params.get('table');

    if (urlView === 'kitchen') {
      setAuthModalTarget('kitchen');
      setIsAdminAuthModalOpen(true);
      setCurrentView('customer');
    } else if (urlView === 'admin') {
      setAuthModalTarget('admin');
      setIsAdminAuthModalOpen(true);
      setCurrentView('customer');
    }

    if (urlTable) {
      const parsedNum = parseInt(urlTable, 10);
      if (!isNaN(parsedNum) && parsedNum > 0) {
        setTableNumber(parsedNum);
        setIsTableModalOpen(false);
        if (!urlView) setCurrentView('customer');
      } else {
        setIsTableModalOpen(true);
      }
    } else {
      setTableNumber(1); // Default to Table 1
    }

    // Fetch initial state from server API
    fetchState();
  }, []);

  // Publicly-readable data: menu + tables always, plus only the orders for
  // the current table (customers should never receive every other table's
  // orders or the full loyalty member list — that was a data-exposure bug
  // in the original build).
  const fetchState = async () => {
    try {
      const [menuRes, tablesRes] = await Promise.all([
        fetch('/api/menu').then(r => (r.ok ? r.json() : null)),
        fetch('/api/tables').then(r => (r.ok ? r.json() : null))
      ]);
      if (menuRes) setMenuItems(menuRes);
      if (tablesRes) setTables(tablesRes);

      if (tableNumber) {
        const myOrders = await fetch(`/api/orders/table/${tableNumber}`).then(r => (r.ok ? r.json() : null));
        if (myOrders) setOrders(myOrders);
      }
    } catch {
      showError('Could not load the latest menu/table data. Pull to refresh or check your connection.');
    }
  };

  // Full order list + loyalty list are admin/kitchen-only. Fetch them once
  // logged into either view, and refresh whenever that view is active.
  const fetchStaffState = async () => {
    try {
      const ordersRawRes = await fetch('/api/orders');
      if (ordersRawRes.status === 402) {
        setSubscriptionBlocked(true);
        return;
      }
      const [ordersRes, loyaltyRes, waiterCallsRes] = await Promise.all([
        ordersRawRes.ok ? ordersRawRes.json() : null,
        fetch('/api/loyalty').then(r => (r.ok ? r.json() : null)),
        fetch('/api/admin/waiter-calls?pending=true').then(r => (r.ok ? r.json() : null))
      ]);
      setSubscriptionBlocked(false);
      if (ordersRes) setOrders(ordersRes);
      if (loyaltyRes) setLoyaltyMembers(loyaltyRes);
      if (waiterCallsRes) setWaiterCalls(waiterCallsRes);
    } catch {
      showError('Could not refresh orders/loyalty data.');
    }
  };

  useEffect(() => {
    if (currentView === 'admin' || currentView === 'kitchen') {
      fetchStaffState();
    }
  }, [currentView]);

  // Branding (logo/color) — fetched whenever we know which restaurant we're
  // looking at, so the customer menu and admin dashboard can theme
  // themselves instead of looking like a generic shared template.
  useEffect(() => {
    fetch('/api/settings')
      .then(r => (r.ok ? r.json() : null))
      .then(data => {
        if (data) {
          setBranding({
            logoUrl: data.logoUrl || null,
            brandColor: data.brandColor || null,
            restaurantName: data.restaurantName || null,
            contactPhone: data.contactPhone || null,
            contactAddress: data.contactAddress || null,
            contactInstagram: data.contactInstagram || null,
            workingHours: data.workingHours || null
          });
          if (data.deliveryStatus) setDeliveryStatus(data.deliveryStatus);
        }
      })
      .catch(() => {});
  }, [loggedInRestaurantId, tableNumber]);

  const handleResolveWaiterCall = async (callId: string) => {
    setWaiterCalls(prev => prev.map(c => (c.id === callId ? { ...c, status: 'resolved' } : c)));
    try {
      const res = await fetch(`/api/admin/waiter-calls/${callId}/resolve`, { method: 'POST' });
      if (!res.ok) throw new Error('failed');
    } catch {
      showError("Ofitsiant chaqiruvini belgilashda xatolik yuz berdi.");
      fetchStaffState();
    }
  };

  // View Switcher with Security Lock for Kitchen & Admin
  const handleViewChange = (newView: AppViewMode) => {
    if (newView === 'kitchen' && !isKitchenAuthenticated) {
      setAuthModalTarget('kitchen');
      setIsAdminAuthModalOpen(true);
      return;
    }
    if (newView === 'admin' && !isAdminAuthenticated) {
      setAuthModalTarget('admin');
      setIsAdminAuthModalOpen(true);
      return;
    }
    setCurrentView(newView);
  };

  const handleRegisterRestaurant = async (name: string, phone: string, pass: string, deliveryEnabled: boolean): Promise<boolean> => {
    try {
      const res = await fetch('/api/restaurants/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone, password: pass, deliveryEnabled })
      });
      if (!res.ok) return false;
      const data = await res.json().catch(() => null);
      if (data?.restaurantId) {
        setLoggedInRestaurantId(data.restaurantId);
        setRestaurantId(data.restaurantId);
      }
      if (data?.name) setLoggedInRestaurantName(data.name);
      setDeliveryStatus(data?.deliveryEnabled ? 'active' : 'disabled');
      setIsAdminAuthenticated(true);
      setIsAdminAuthModalOpen(false);
      setCurrentView('admin');
      return true;
    } catch {
      showError('Could not reach the server. Check your connection and try again.');
      return false;
    }
  };

  const handleAuthenticateAdmin = async (phone: string, pass: string): Promise<boolean> => {
    const endpoint = authModalTarget === 'kitchen' ? '/api/auth/kitchen/login' : '/api/auth/admin/login';
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, password: pass })
      });
      if (!res.ok) return false;
      const data = await res.json().catch(() => null);
      if (data?.restaurantId) {
        setLoggedInRestaurantId(data.restaurantId);
        setRestaurantId(data.restaurantId);
      }
      if (data?.restaurantName) setLoggedInRestaurantName(data.restaurantName);
      if (data?.subscriptionPeriodEnd) setSubscriptionPeriodEnd(data.subscriptionPeriodEnd);
      if (data?.deliveryStatus) setDeliveryStatus(data.deliveryStatus);

      if (authModalTarget === 'kitchen') {
        setIsKitchenAuthenticated(true);
        setIsAdminAuthModalOpen(false);
        setCurrentView('kitchen');
      } else {
        setIsAdminAuthenticated(true);
        setIsAdminAuthModalOpen(false);
        setCurrentView('admin');
      }
      return true;
    } catch {
      showError('Could not reach the server. Check your connection and try again.');
      return false;
    }
  };

  const handleLockAdmin = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // Even if the network call fails, still clear local UI state below.
    }
    setIsAdminAuthenticated(false);
    setIsKitchenAuthenticated(false);
    setSubscriptionBlocked(false);
    setRestaurantId('default');
    setCurrentView('customer');
  };

  // Keep active order updated for current table (dine-in) or the active
  // delivery order (identified by id, since delivery orders don't have a
  // real table number to match against).
  useEffect(() => {
    if (orderMode === 'delivery') {
      setActiveCustomerOrder(prev => {
        if (!prev) return prev;
        const updated = orders.find(o => o.id === prev.id);
        return updated || prev;
      });
      return;
    }
    if (tableNumber) {
      const tableOrder = orders.find(o => o.tableNumber === tableNumber && o.status !== 'paid' && o.status !== 'cancelled');
      setActiveCustomerOrder(tableOrder || null);
    }
  }, [tableNumber, orders, orderMode]);

  // Cart operations
  const handleDirectAddToCart = (dish: MenuItem) => {
    setCartItems(prev => {
      const existingIndex = prev.findIndex(
        i => i.menuItem.id === dish.id && i.selectedCustomizations.length === 0 && !i.specialInstructions
      );
      if (existingIndex > -1) {
        const updated = [...prev];
        const existing = updated[existingIndex];
        const newQty = existing.quantity + 1;
        updated[existingIndex] = {
          ...existing,
          quantity: newQty,
          itemTotal: dish.price * newQty
        };
        return updated;
      }
      const cartItemId = 'cart-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5);
      return [
        ...prev,
        {
          cartItemId,
          menuItem: dish,
          quantity: 1,
          selectedCustomizations: [],
          specialInstructions: '',
          itemTotal: dish.price
        }
      ];
    });
  };

  const handleAddToCart = (itemData: Omit<CartItem, 'cartItemId'>) => {
    const cartItemId = 'cart-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5);
    setCartItems(prev => [...prev, { ...itemData, cartItemId }]);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveCartItem(cartItemId);
    } else {
      setCartItems(prev => prev.map(item => {
        if (item.cartItemId === cartItemId) {
          const unitPrice = item.itemTotal / item.quantity;
          return {
            ...item,
            quantity: newQty,
            itemTotal: unitPrice * newQty
          };
        }
        return item;
      }));
    }
  };

  const handleRemoveCartItem = (cartItemId: string) => {
    setCartItems(prev => prev.filter(i => i.cartItemId !== cartItemId));
  };

  // Submit Order to Kitchen
  const handleSubmitOrder = async (orderConfig: {
    paymentMethod: 'pay_at_counter' | 'card' | 'cash';
    loyaltyPointsRedeemed: number;
    orderNote: string;
  }) => {
    const subtotal = cartItems.reduce((acc, item) => acc + item.itemTotal, 0);
    const tax = subtotal * 0.08;
    const serviceCharge = subtotal * 0.05;
    const discount = orderConfig.loyaltyPointsRedeemed * 100;
    const totalAmount = Math.max(0, subtotal + tax + serviceCharge - discount);
    const isDelivery = orderMode === 'delivery';

    const payload = {
      tableNumber: isDelivery ? 0 : (tableNumber || 1),
      customerName: customerName || (isDelivery ? 'Dostavka mijozi' : `Table ${tableNumber || 1} Guest`),
      customerPhoneOrEmail: customerPhoneOrEmail || '',
      items: cartItems,
      subtotal,
      tax,
      serviceCharge,
      discount,
      totalAmount,
      loyaltyPointsRedeemed: orderConfig.loyaltyPointsRedeemed,
      paymentMethod: orderConfig.paymentMethod,
      orderNote: orderConfig.orderNote,
      orderType: isDelivery ? 'delivery' : 'dine_in',
      deliveryAddress: isDelivery ? deliveryAddress : undefined,
      deliveryPhone: isDelivery ? deliveryPhone : undefined
    };

    // A stable idempotency key per submit attempt so a flaky mobile network
    // retry can never create two real orders for one tap of "confirm".
    const idempotencyKey = `order-${isDelivery ? 'delivery' : tableNumber}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Idempotency-Key': idempotencyKey },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const createdOrder: Order = await res.json();
        setOrders(prev => [createdOrder, ...prev]);
        setActiveCustomerOrder(createdOrder);
        setCartItems([]);
      } else {
        const body = await res.json().catch(() => ({ error: 'Could not place your order.' }));
        showError(body.error || 'Could not place your order. Please try again.');
      }
    } catch {
      showError('Could not reach the kitchen. Check your connection and try again — your order was NOT placed.');
    }
  };

  // Kitchen / Admin Update Order Status
  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus, paymentStatus?: 'paid' | 'unpaid') => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, paymentStatus })
      });

      if (res.ok) {
        const updated: Order = await res.json();
        setOrders(prev => prev.map(o => o.id === orderId ? updated : o));
      } else {
        showError('Could not update order status. Please try again.');
      }
    } catch {
      showError('Could not reach the server to update order status.');
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}`, { method: 'DELETE' });
      if (res.ok) {
        setOrders(prev => prev.filter(o => o.id !== orderId));
      } else {
        showError('Could not delete this order. Please try again.');
      }
    } catch {
      showError('Could not reach the server to delete this order.');
    }
  };

  const handleCleanupOldOrders = async (olderThanDays: number): Promise<number | null> => {
    try {
      const res = await fetch('/api/admin/orders/cleanup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ olderThanDays })
      });
      if (res.ok) {
        const result = await res.json();
        await fetchStaffState(); // refresh the order list to reflect the deletion
        return result.ordersDeleted;
      }
      showError('Could not clean up old orders. Please try again.');
      return null;
    } catch {
      showError('Could not reach the server to clean up old orders.');
      return null;
    }
  };

  const handleUpdateExchangeRate = async (currency: 'USD' | 'RUB', rateToSom: number) => {
    try {
      const res = await fetch('/api/admin/exchange-rates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currency, rateToSom })
      });
      if (!res.ok) {
        showError(`Could not update the ${currency} exchange rate. Please try again.`);
      }
    } catch {
      showError(`Could not reach the server to update the ${currency} exchange rate.`);
    }
  };

  const handleUpdateSettings = async (settings: { taxPercent?: number; serviceFeePercent?: number }) => {
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      if (!res.ok) {
        showError('Could not update the setting. Please try again.');
      }
    } catch {
      showError('Could not reach the server to update the setting.');
    }
  };

  const handleUpdateBranding = async (params: {
    logoUrl?: string | null;
    brandColor?: string | null;
    displayName?: string;
    contactPhone?: string;
    contactAddress?: string;
    contactInstagram?: string;
    workingHours?: string;
  }): Promise<boolean> => {
    try {
      const res = await fetch('/api/admin/branding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      if (!res.ok) {
        showError("Brendlashni saqlashda xatolik yuz berdi.");
        return false;
      }
      const data = await res.json();
      setBranding({
        logoUrl: data.logoUrl,
        brandColor: data.brandColor,
        restaurantName: data.restaurantName,
        contactPhone: data.contactPhone,
        contactAddress: data.contactAddress,
        contactInstagram: data.contactInstagram,
        workingHours: data.workingHours
      });
      if (data.restaurantName) setLoggedInRestaurantName(data.restaurantName);
      return true;
    } catch {
      showError("Serverga ulanib bo'lmadi.");
      return false;
    }
  };

  const handleGenerateTelegramLink = async (): Promise<{ token: string; deepLink: string } | null> => {
    try {
      const res = await fetch('/api/admin/telegram/link-token', { method: 'POST' });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  };

  const handleCheckTelegramLinkStatus = async (token: string) => {
    try {
      const res = await fetch(`/api/admin/telegram/link-status/${token}`);
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  };

  const handleUnlinkTelegram = async (): Promise<boolean> => {
    try {
      const res = await fetch('/api/admin/telegram/unlink', { method: 'POST' });
      return res.ok;
    } catch {
      return false;
    }
  };

  // Admin Update Menu Item / Stock
  const handleUpdateMenuItem = async (updatedItem: MenuItem) => {
    try {
      const res = await fetch(`/api/menu/${updatedItem.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedItem)
      });

      if (res.ok) {
        const item: MenuItem = await res.json();
        setMenuItems(prev => prev.map(m => m.id === item.id ? item : m));
      } else {
        const body = await res.json().catch(() => ({ error: 'Could not save menu item changes.' }));
        showError(describeApiError(body) || 'Could not save menu item changes. Please try again.');
      }
    } catch {
      showError('Could not reach the server to save menu item changes.');
    }
  };

  // Admin Add New Dish
  const handleAddMenuItem = async (newItem: Partial<MenuItem>) => {
    try {
      const res = await fetch('/api/menu', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItem)
      });

      if (res.ok) {
        const added: MenuItem = await res.json();
        setMenuItems(prev => [...prev, added]);
      } else {
        const body = await res.json().catch(() => ({ error: 'Could not add dish.' }));
        showError(describeApiError(body) || 'Could not add dish. Please check the fields and try again.');
      }
    } catch {
      showError('Could not reach the server to add the dish.');
    }
  };

  // Admin Delete Menu Item
  const handleDeleteMenuItem = async (id: string) => {
    try {
      const res = await fetch(`/api/menu/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setMenuItems(prev => prev.filter(m => m.id !== id));
      } else {
        showError('Could not delete this dish. Please try again.');
      }
    } catch {
      showError('Could not reach the server to delete this dish.');
    }
  };

  // Admin Add Table
  const handleCallWaiter = async (tableNum: number): Promise<boolean> => {
    try {
      const res = await fetch('/api/waiter-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableNumber: tableNum })
      });
      return res.ok;
    } catch {
      return false;
    }
  };

  const handleAddTable = async (tableNumber: number, capacity: number, comment?: string) => {
    try {
      const res = await fetch('/api/tables', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableNumber, capacity, comment: comment || '' })
      });
      if (res.ok) {
        const table: Table = await res.json();
        setTables(prev => {
          const exists = prev.some(t => t.tableNumber === table.tableNumber);
          if (exists) return prev.map(t => t.tableNumber === table.tableNumber ? table : t);
          return [...prev, table].sort((a, b) => a.tableNumber - b.tableNumber);
        });
      } else {
        showError('Could not save the table. Please try again.');
      }
    } catch {
      showError('Could not reach the server to save the table.');
    }
  };

  // Admin Delete Table
  const handleDeleteTable = async (tableNumber: number) => {
    try {
      const res = await fetch(`/api/tables/${tableNumber}`, { method: 'DELETE' });
      if (res.ok) {
        setTables(prev => prev.filter(t => t.tableNumber !== tableNumber));
      } else {
        showError('Could not delete this table. Please try again.');
      }
    } catch {
      showError('Could not reach the server to delete this table.');
    }
  };

  // Verify Loyalty Member Code (customer self-service: exact match on their
  // own phone/email only, via the public lookup endpoint)
  const handleVerifyLoyalty = async (query: string, code: string) => {
    try {
      const res = await fetch(`/api/loyalty/lookup?identifier=${encodeURIComponent(query)}`);
      if (res.ok) {
        const member: LoyaltyMember | null = await res.json();
        if (member) {
          setCurrentLoyaltyMember(member);
          setCustomerName(member.name);
          return;
        }
      }
      // No existing member found -> register a new one.
      const regRes = await fetch('/api/loyalty', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: customerName, phoneOrEmail: query, confirmationCode: code })
      });
      if (regRes.ok) {
        const newMem = await regRes.json();
        setCurrentLoyaltyMember(newMem);
      } else {
        showError('Could not verify or register loyalty membership. Please try again.');
      }
    } catch {
      showError('Could not reach the server to verify loyalty membership.');
    }
  };

  const cartSubtotal = cartItems.reduce((acc, item) => acc + item.itemTotal, 0);

  return (
    <CurrencyProvider>
    <div className="min-h-screen bg-zinc-100 text-zinc-900 font-sans selection:bg-orange-500 selection:text-white">

      {/* Global error toast: replaces the old "silently pretend it worked" behavior */}
      {errorToast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] bg-red-600 text-white px-4 py-3 rounded-xl shadow-lg text-sm font-medium max-w-md text-center">
          {errorToast}
        </div>
      )}

      {/* Persistent App Navigation Header */}
      <HeaderNav
        currentView={currentView}
        onViewChange={handleViewChange}
        tableNumber={tableNumber}
        onChangeTableClick={() => setIsTableModalOpen(true)}
        onOpenQRScanner={() => setIsQRScannerModalOpen(true)}
        onOpenLocation={() => setIsLocationModalOpen(true)}
        onOpenGoogleAuth={() => setIsGoogleAuthModalOpen(true)}
        googleUser={googleUser}
        isRealtimeConnected={isRealtimeConnected}
        cartCount={cartItems.reduce((acc, i) => acc + i.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenLoyalty={() => setIsLoyaltyModalOpen(true)}
        loyaltyPoints={currentLoyaltyMember?.pointsBalance}
        customerName={customerName}
        lang={lang}
        onLanguageChange={setLang}
        isAdminAuthenticated={isAdminAuthenticated}
        isKitchenAuthenticated={isKitchenAuthenticated}
        branding={branding}
      />

      {/* Main View Router */}
      <main>
        {currentView === 'customer' && (
          <>
            <CustomerView
              menuItems={menuItems}
              tableNumber={tableNumber || 1}
              tableComment={tables.find(t => t.tableNumber === (tableNumber || 1))?.comment}
              onSelectItem={(item) => setSelectedDishForCustomization(item)}
              onDirectAddToCart={handleDirectAddToCart}
              cartCount={cartItems.reduce((acc, i) => acc + i.quantity, 0)}
              cartSubtotal={cartSubtotal}
              onOpenCart={() => setIsCartOpen(true)}
              onOpenQRScanner={() => setIsQRScannerModalOpen(true)}
              onOpenLocation={() => setIsLocationModalOpen(true)}
              onOpenGoogleAuth={() => setIsGoogleAuthModalOpen(true)}
              lang={lang}
              onLanguageChange={setLang}
              activeOrder={activeCustomerOrder}
              logoUrl={branding.logoUrl}
              brandColor={branding.brandColor}
              restaurantName={branding.restaurantName}
              contactPhone={branding.contactPhone}
              contactAddress={branding.contactAddress}
              contactInstagram={branding.contactInstagram}
              onCallWaiter={handleCallWaiter}
              deliveryEnabled={deliveryStatus === 'active'}
              orderMode={orderMode}
              onToggleOrderMode={() => setOrderMode(prev => (prev === 'delivery' ? 'dine_in' : 'delivery'))}
            />

            {/* Active Order Progress Bar (Customer View) */}
            <OrderStatusTracker activeOrder={activeCustomerOrder} hasCartItems={cartItems.length > 0} lang={lang} />
          </>
        )}

        {(currentView === 'kitchen' || currentView === 'admin') && (isAdminAuthenticated || isKitchenAuthenticated) && subscriptionBlocked && (
          <div className="min-h-[70vh] flex items-center justify-center p-6">
            <div className="max-w-sm w-full bg-white border border-rose-200 rounded-2xl p-6 text-center space-y-3 shadow-sm">
              <div className="text-3xl">⏸️</div>
              <h2 className="text-lg font-black text-zinc-900">Obuna to'xtatilgan</h2>
              <p className="text-sm text-zinc-500">
                Ushbu restoran uchun obuna faol emas. Tizimdan foydalanishni davom ettirish uchun administrator bilan bog'laning.
              </p>
              <button
                onClick={handleLockAdmin}
                className="w-full bg-zinc-900 hover:bg-black text-white font-bold py-2.5 rounded-xl text-sm transition-colors"
              >
                Chiqish
              </button>
            </div>
          </div>
        )}

        {currentView === 'kitchen' && isKitchenAuthenticated && !subscriptionBlocked && (
          <KitchenDisplay
            orders={orders}
            onUpdateStatus={handleUpdateOrderStatus}
            lang={lang}
            waiterCalls={waiterCalls}
            onResolveWaiterCall={handleResolveWaiterCall}
          />
        )}

        {currentView === 'admin' && isAdminAuthenticated && !subscriptionBlocked && tables.length === 0 && !onboardingDismissed && (
          <OnboardingWizard
            restaurantName={loggedInRestaurantName}
            onAddTable={handleAddTable}
            onAddMenuItem={handleAddMenuItem}
            onUpdateKitchenPin={handleUpdateKitchenPin}
            onFinish={() => setOnboardingDismissed(true)}
          />
        )}

        {currentView === 'admin' && isAdminAuthenticated && !subscriptionBlocked && (tables.length > 0 || onboardingDismissed) && (
          <>
            {(() => {
              if (!subscriptionPeriodEnd) return null;
              const daysLeft = Math.ceil((new Date(subscriptionPeriodEnd).getTime() - Date.now()) / (24 * 60 * 60 * 1000));
              if (daysLeft > 3) return null;
              return (
                <div className={`px-4 py-2.5 text-center text-xs font-bold ${daysLeft <= 0 ? 'bg-rose-600 text-white' : 'bg-amber-400 text-amber-950'}`}>
                  {daysLeft <= 0
                    ? "Obunangiz muddati tugadi — to'lov uchun administrator bilan bog'laning."
                    : `Obunangiz ${daysLeft} kundan keyin tugaydi — davom etish uchun administrator bilan bog'laning.`}
                </div>
              );
            })()}
            <AdminDashboard
            menuItems={menuItems}
            orders={orders}
            tables={tables}
            loyaltyMembers={loyaltyMembers}
            waiterCalls={waiterCalls}
            onResolveWaiterCall={handleResolveWaiterCall}
            branding={branding}
            onUpdateBranding={handleUpdateBranding}
            onGenerateTelegramLink={handleGenerateTelegramLink}
            onCheckTelegramLinkStatus={handleCheckTelegramLinkStatus}
            onUnlinkTelegram={handleUnlinkTelegram}
            deliveryStatus={deliveryStatus}
            onUpdateAdminPassword={handleUpdateAdminPassword}
            onUpdateKitchenPin={handleUpdateKitchenPin}
            onUpdateMenuItem={handleUpdateMenuItem}
            onAddMenuItem={handleAddMenuItem}
            onDeleteMenuItem={handleDeleteMenuItem}
            onAddTable={handleAddTable}
            onDeleteTable={handleDeleteTable}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onDeleteOrder={handleDeleteOrder}
            onCleanupOldOrders={handleCleanupOldOrders}
            onUpdateExchangeRate={handleUpdateExchangeRate}
            onUpdateSettings={handleUpdateSettings}
            onLockAdmin={handleLockAdmin}
            appUrl={appUrl}
            restaurantId={loggedInRestaurantId}
            lang={lang}
          />
          </>
        )}
      </main>

      {/* MODALS & DRAWERS */}
      
      {/* Admin / Kitchen Authentication Lock Modal */}
      <AdminAuthModal
        isOpen={isAdminAuthModalOpen}
        onClose={() => setIsAdminAuthModalOpen(false)}
        onAuthenticate={handleAuthenticateAdmin}
        onRegister={handleRegisterRestaurant}
        lang={lang}
        targetView={authModalTarget}
      />

      {/* Table QR Camera Scanner Modal */}
      <QRScannerModal
        isOpen={isQRScannerModalOpen}
        onClose={() => setIsQRScannerModalOpen(false)}
        onSelectTable={(num) => setTableNumber(num)}
        lang={lang}
      />

      {/* 1. Table Selection / Confirmation Modal */}
      <TableConfirmModal
        isOpen={isTableModalOpen}
        currentTable={tableNumber}
        tables={tables}
        onConfirm={(num) => {
          setTableNumber(num);
          setIsTableModalOpen(false);
        }}
        lang={lang}
      />

      {/* 2. Dish Customizer Modal */}
      <ItemCustomizerModal
        item={selectedDishForCustomization}
        isOpen={!!selectedDishForCustomization}
        onClose={() => setSelectedDishForCustomization(null)}
        onAddToCart={handleAddToCart}
        lang={lang}
      />

      {/* 3. Shopping Cart & Bill Breakdown Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveCartItem}
        tableNumber={tableNumber || 1}
        customerName={customerName}
        setCustomerName={setCustomerName}
        customerPhoneOrEmail={customerPhoneOrEmail}
        setCustomerPhoneOrEmail={setCustomerPhoneOrEmail}
        confirmationCode={confirmationCode}
        setConfirmationCode={setConfirmationCode}
        loyaltyMember={currentLoyaltyMember}
        onVerifyLoyalty={handleVerifyLoyalty}
        googleUser={googleUser}
        onOpenGoogleAuth={() => setIsGoogleAuthModalOpen(true)}
        onSubmitOrder={handleSubmitOrder}
        lang={lang}
        orderMode={orderMode}
        deliveryAddress={deliveryAddress}
        setDeliveryAddress={setDeliveryAddress}
        deliveryPhone={deliveryPhone}
        setDeliveryPhone={setDeliveryPhone}
      />

      {/* 4. Loyalty Profile & Order History Modal */}
      <OrderHistoryModal
        isOpen={isLoyaltyModalOpen}
        onClose={() => setIsLoyaltyModalOpen(false)}
        member={currentLoyaltyMember}
        orders={orders.filter(o => o.tableNumber === tableNumber || o.customerPhoneOrEmail === customerPhoneOrEmail)}
        lang={lang}
      />

      {/* 5. Google OAuth Authentication Modal */}
      <GoogleAuthModal
        isOpen={isGoogleAuthModalOpen}
        onClose={() => setIsGoogleAuthModalOpen(false)}
        currentUser={googleUser}
        onSignInSuccess={handleSignInGoogle}
        onSignOut={handleSignOutGoogle}
        lang={lang}
      />

      {/* 6. Restaurant Location & Contact Modal */}
      <RestaurantLocationModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
        branding={branding}
      />

      {/* 7. Welcome Intro Animation Splash */}
      <WelcomeSplash
        isOpen={isWelcomeSplashOpen}
        onClose={() => setIsWelcomeSplashOpen(false)}
        lang={lang}
        onSelectLang={(newLang) => setLang(newLang)}
        branding={branding}
      />

    </div>
    </CurrencyProvider>
  );
}
