import QRCode from 'qrcode';

/**
 * Builds the URL a table's QR code should point to. Includes ?r=<restaurantId>
 * when provided (every restaurant created after the multi-tenant upgrade) so
 * a scanning customer's browser knows which restaurant they're ordering
 * from — omitted for the legacy "default" tenant so already-printed QR
 * codes keep resolving the same way as before.
 */
export function getTableFullUrl(tableNumber: number, appUrl: string, restaurantId?: string): string {
  const base = `${appUrl.replace(/\/$/, '')}?table=${tableNumber}`;
  if (restaurantId && restaurantId !== 'default') {
    return `${base}&r=${encodeURIComponent(restaurantId)}`;
  }
  return base;
}

/**
 * Generates a real, standard, 100% camera-scannable QR code Data URL for a table.
 */
export async function generateTableQRDataUrlAsync(
  tableNumber: number,
  appUrl: string,
  restaurantId?: string
): Promise<string> {
  const fullUrl = getTableFullUrl(tableNumber, appUrl, restaurantId);
  try {
    return await QRCode.toDataURL(fullUrl, {
      width: 400,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M'
    });
  } catch (e) {
    console.error('Error generating QR code:', e);
    return '';
  }
}
