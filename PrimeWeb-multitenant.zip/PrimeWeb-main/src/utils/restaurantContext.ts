// ---------------------------------------------------------------------------
// Multi-tenant support for the CUSTOMER-facing app. A customer scans a QR
// code that encodes both the table number and which restaurant it belongs
// to (?table=5&r=rest-abc123). Since a dining guest has no login session,
// the server has no other way to know which restaurant's menu/orders/tables
// to show them — this file captures that restaurant id once on page load
// and quietly attaches it to every API call from then on, via a header, so
// none of the existing components (CustomerView, AdminDashboard, etc.) need
// to be rewritten to pass it around manually.
//
// Falls back to "default" (the original single-restaurant deployment) if no
// ?r= param is present, so existing printed QR codes keep working exactly
// as before until they're reprinted with the new multi-tenant links.
// ---------------------------------------------------------------------------

const STORAGE_KEY = 'primeweb_restaurant_id';
const DEFAULT_RESTAURANT_ID = 'default';

export function getRestaurantId(): string {
  try {
    return sessionStorage.getItem(STORAGE_KEY) || DEFAULT_RESTAURANT_ID;
  } catch {
    return DEFAULT_RESTAURANT_ID;
  }
}

export function setRestaurantId(id: string) {
  try {
    sessionStorage.setItem(STORAGE_KEY, id);
  } catch {
    /* sessionStorage unavailable (e.g. some in-app browsers) — the default
       tenant fallback still keeps the app functional */
  }
}

// Appends the restaurant id as a query param to a URL that's about to be
// opened as an EventSource (which can't carry custom headers).
export function withRestaurantParam(url: string): string {
  const separator = url.includes('?') ? '&' : '?';
  return `${url}${separator}r=${encodeURIComponent(getRestaurantId())}`;
}

export function initRestaurantContext() {
  try {
    const params = new URLSearchParams(window.location.search);
    const fromUrl = params.get('r');
    if (fromUrl) setRestaurantId(fromUrl);
  } catch {
    /* ignore */
  }

  // Every existing fetch('/api/...') call in the app keeps working
  // unmodified — this just adds one header before the request goes out.
  const originalFetch = window.fetch.bind(window);
  window.fetch = (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : (input as Request).url;
    if (url && url.startsWith('/api/')) {
      const headers = new Headers(init?.headers || (input instanceof Request ? input.headers : undefined));
      if (!headers.has('X-Restaurant-Id')) {
        headers.set('X-Restaurant-Id', getRestaurantId());
      }
      return originalFetch(input, { ...init, headers });
    }
    return originalFetch(input, init);
  };
}
